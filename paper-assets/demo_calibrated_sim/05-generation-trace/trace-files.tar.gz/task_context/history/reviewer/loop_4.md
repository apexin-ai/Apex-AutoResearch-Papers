---
loop: 4
reason: idle_timeout
updated: '2026-05-13T01:06:10+00:00'
---

### 1. 🔴 硬约束 / 红线
- 本项目 gpu_ids=[2,3]，cuda:0/1/4/5 绝对不能用。mvp-003 曾因 cuda:1 被 CRITICAL kill。
- eval_mistral_bcp.sh 已加硬检查（`GPU_ID` 必须显式传 2 或 3），但 Agent 提交时仍需核实 CUDA_VISIBLE_DEVICES。
- GPU 5 上 PID 279220（`structfuse-context`）、GPU 0/1 上 PID 631287/633173（`rl-active-probe-fl`）是其他项目，不要误判为越界。
- Mistral BCP 评估需等 hgate-dpo003 结果（D008 决策门）才能启动，不能提前部署占 GPU。

### 2. 🖥️ 基础设施快照
- 服务器：cqa1-21977(root)，工作目录 `/root/democalib`，时区 Asia/Shanghai (UTC+8)
- Python：`/root/miniconda3/bin/python`，conda base 环境，无 venv
- 模型：Qwen2.5-7B-Instruct → `/root/autodl-tmp/models/Qwen/Qwen2.5-7B-Instruct`
- Mistral-7B-v0.3 → `/root/autodl-tmp/models/Mistral-7B-Instruct-v0.3`（已下载完整，未部署）
- Llama-3-8B → `/root/autodl-tmp/models/Meta-Llama-3-8B-Instruct/`（已判无效，不再用）
- DPO adapters：v1 `/root/democalib/dpo_output/`，v2 `/root/democalib/dpo_output_v2/`，v3 `/root/democalib/dpo_output_v3/`
- HF cache：`/root/autodl-tmp/.hf_cache`
- W&B：未配置（WANDB_MODE=disabled），不检查 W&B
- 活跃进程：vLLM PID 55024 (cuda:2, port 8002, hgate-dpo003)；vLLM PID 311950 (cuda:3, port ?, hgate-dpo002)
- 本地 workspace：`/home/ubuntu/.agent-ml-research-idea_gen_0509_2/projects/demo_calibrated_sim/`

### 3. 📊 当前状态
**我的最后动作**：审查了 4 个 worker（eval_hgate-dpo003 提交、check_eval-progress、infra_mistral-verify、code_mistral-bcp-prep + fix），均 PASS/WARNING，已全部 post 给 Director。

**RUNNING 实验**：
- **hgate-dpo003**（cuda:2）：DPO v3 (Fix B, 0% mismatch) H-gate 评估。4 runs × 6 variants × 20 tasks。上次检查 run_1 完成 2/6 variant（约 8%）。预计还需 ~8-10h。**这是 MVP 决策节点。**
- **hgate-dpo002**（cuda:3）：DPO v2 (有 TRL mismatch) H-gate 评估，对照组。run_1 已完成（H1=PASS, H2=FAIL, H3=FAIL），run_2 进行中。约 30% 完成。

**关键初步发现**（已报告 Director）：hgate-dpo002 run_1 显示 DPO-002 baseline completion=22.2%（原始 Qwen 36.8%），DPO 训练导致 completion 退化 ~15pp。BCP variant politeness 不降反升。等 hgate-dpo003 对比。

### 4. 📋 待办（条件触发式）
- hgate-dpo003 全部完成 → 独立核实 H2/H3 gate 结果，与 hgate-dpo001（FAIL, 21.3%）和 hgate-dpo002 交叉对比，检查 cherry-picking
- hgate-dpo003 H2+H3 双 PASS → Plan A（DPO 方法论文），关注 claim 强度是否匹配 evidence
- hgate-dpo003 双 FAIL → Plan B 触发，Mistral BCP 部署（D008：completion≤20% 则 KILL），需核实 GPU_ID 传参
- Agent 提交 Mistral eval → 立即检查 GPU_ID 是否为 2 或 3，检查 `SERVED_MODEL_NAME` 与 `run_mvp_experiment.py` 兼容性
- 任何新实验注册 → 核实 spec 完整性（命令、服务器、数据路径、seed）

### 5. 🎯 战略上下文
- **决策链**：D001(MVP 三阶段) → D002(politeness 为主) → D003(BCP 失败转 DPO) → D004(BCP 三失败机制可发表) → D005(决策树) → D006(TRL mismatch 确认) → D007/D008(Llama 无效→hedge Mistral) → D009(Reviewer 修正 overclaim)
- **核心分叉点**：hgate-dpo003 是 Plan A vs Plan B 的唯一决策节点。dpo-003 训练指标远好于 dpo-001/002（accuracy 0.75-1.0 vs 0.5/0.667），但训练 loss 好≠下游 eval 好——hgate-dpo001 就是训练"成功"但 eval 失败的先例。
- **最容易判断错的事**：(1) 不要因为 dpo-003 训练指标好就预判 hgate-dpo003 会 PASS；(2) hgate-dpo002 的 completion 退化（22.2% vs 36.8%）可能是 DPO 对 tool-calling 的通用破坏而非 mismatch 特有问题——如果 hgate-dpo003 也退化，DPO 路线本身有问题；(3) GPU 5 上的 `structfuse-context` 和 GPU 0/1 上的 `rl-active-probe-fl` 是其他项目，不是越界。
