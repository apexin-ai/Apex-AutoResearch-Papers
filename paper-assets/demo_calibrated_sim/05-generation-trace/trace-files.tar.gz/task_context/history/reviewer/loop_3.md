---
loop: 3
reason: idle_timeout
updated: '2026-05-12T21:08:07+00:00'
---

### 1. 🔴 硬约束 / 红线
- 本项目 gpu_ids=[2,3]，仅 cuda:2 和 cuda:3 可用。GPU 0/1/4/5 有其他项目进程，绝不能占用
- 服务器 cqa1-21977，账号 root。只有这一台服务器
- WANDB_MODE=disabled（dpo-003），无法用 wandb 交叉验证，只能靠日志
- H-gate eval 必须报告全部 runs，不允许 cherry-picking（dpo-001 eval 曾有方差 10%-30%）
- dpo-003 spec 里 `--gpu-id 0` 是 CUDA_VISIBLE_DEVICES=2 下的逻辑 ID，物理卡是 cuda:2，不是违规

### 2. 🖥️ 基础设施快照
- 服务器：cqa1-21977(root)，6×RTX 4090D (24GB each)
- 工作目录：`/root/democalib/`
- Python：`/root/miniconda3/bin/python`（conda base 环境，不是 venv）
- 模型：`/root/autodl-tmp/models/Qwen/Qwen2.5-7B-Instruct/`（主力 15GB），`/root/autodl-tmp/models/Mistral-7B-Instruct-v0.3/`（Plan B，14GB）
- 残留可删：`/root/autodl-tmp/models/Qwen2.5-7B-Instruct-DPO-merged/`（15GB，dpo-001 产物，已 H-gate FAIL）
- DPO 数据：`/root/democalib/data/dpo_pairs_v2.jsonl`（1563 pairs）
- 磁盘：`/root/autodl-tmp/` 81% (33GB free)，已从 98% 清理过
- 活跃进程：dpo-003 训练 (PID 299960, cuda:2, ~49% 完成)；hgate-dpo002 eval (PID 311654, tmux, cuda:3, port 8001, Run 1/4)
- 本地 workspace：`/home/ubuntu/.agent-ml-research-idea_gen_0509_2/projects/demo_calibrated_sim/`

### 3. 📊 当前状态
两个 GPU 都在工作：
- **dpo-003** (cuda:2): Fix B 训练，step ~580/1173 (49.4%), epoch 1.45，ETA ~40 min。Tokenization alignment check PASSED。checkpoint-391 已写入 (64MB)。loss ~0.63-0.65，rewards_accuracy 多数 0.75-1.0
- **hgate-dpo002** (cuda:3): dpo-002 的 H-gate eval，Run 1/4，vLLM port 8001。预计 60-80 min 完成。作为 mismatch 对照组

已完成本轮：磁盘清理核实（29GB 释放，Llama 删除确认），dpo-003 中期审查（训练正常），hgate-dpo002 启动核实（脚本设计合理，GPU 合规）

### 4. 📋 待办
- dpo-003 训练完成 → 核实最终 loss/rewards_accuracy（应优于 dpo-001 的 0.6814/0.5），检查 checkpoint 成功写入，确认无磁盘满错误
- dpo-003 H-gate eval 启动 → 确认用不同端口（≠8001，避免与 hgate-dpo002 冲突），确认 GPU 合规
- dpo-003 H-gate eval 完成 → **独立核实** H2（politeness gap reduction ≥30%）和 H3（completion ≥29.6%），要求全部 runs 报告，计算均值和方差
- hgate-dpo002 完成 → 审查结果（预期 FAIL，100% mismatch），与 hgate-dpo003 对比验证 mismatch 是根因
- H-gate PASS → Plan A（DPO method paper）成立，审查 Agent 结论是否过度 claim
- H-gate FAIL → Plan B 启动：Mistral BCP eval（Mistral 模型已下载），completion 须 >20% 否则 KILL 项目

### 5. 🎯 战略上下文
- **决策链** D001-D009。核心路径：BCP 6/6 FAIL → DPO 路线。dpo-001 有 48% mismatch → H-gate FAIL（completion 21.3% < 29.6%）。根因 TRL #5213（add_generation_prompt=True hardcoded）。dpo-003 用 Fix B 消除 mismatch，是 Plan A 唯一希望
- **训练指标不可靠**：dpo-002 (100% mismatch) 的 loss/accuracy (0.6614/0.667) 反而优于 dpo-001 (48% mismatch, 0.6814/0.5)。说明训练指标不能预测校准质量，只有 H-gate eval 才能判定
- **Llama BCP 无效**（D007/D009）：completion=5% floor effect，已降级为辅助证据
- **Plan B 极弱**：单模型 BCP 失败分析对 EMNLP Findings <30%。需 Mistral completion >20%
- **最容易判断错的事**：
  1. Worker 报 "done" ≠ 实验完成（tmux 后台跑，worker agent 退出了而已）
  2. dpo-001/dpo-002 的 `conclusion: success` 指训练过程完成，不指 H-gate eval 通过
  3. ssh_read_only 不支持管道符 `|` 和重定向 `>`
  4. hgate-dpo002 占用 port 8001，dpo-003 eval 必须用不同端口
