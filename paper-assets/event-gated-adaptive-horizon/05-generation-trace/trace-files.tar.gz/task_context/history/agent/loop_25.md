---
loop: 25
reason: idle_timeout
updated: '2026-05-27T02:26:42+00:00'
---

### 1. 🔴 硬约束 / 红线
- GPU 白名单：westd-51268 cuda:0 / cuda:1，共 2 张。bjb1-45299 宕机不可用
- 数据锁定 5/27，ICML 投稿 5/29。5/27 后不得新增实验数据到论文
- CIVO scope 已精确化为 "multi-joint locomotion"（D149），不可说 "DMC locomotion"
- Cheetah CIVO 跨环境发现：维持 scope + 最小披露 self-correction（D151），不升级 scope
- NVE diagnostic 定位为 practical tool，不升级为独立 contribution（D150）
- exp_102/103 已取消（D157），C3 Cheetah 已有 2-seed 覆盖，不再提交

### 2. 🖥️ 基础设施快照
- **westd-51268**: 2×RTX PRO 6000 Blackwell 96GB, CUDA 13.2
  - 工作目录: /root/autodl-tmp/event-gated-adaptive-horizon/
  - Python: /root/miniconda3/bin/python（conda base）
  - 激活: `source /root/miniconda3/etc/profile.d/conda.sh && conda activate base`
  - logdir: /root/autodl-tmp/event-gated-adaptive-horizon/logdir/
  - 磁盘: 400G/439G 可用
  - CLI flag: `--gate_dt_embed_dim`（两台服务器已统一）
- W&B: entity/project 从 project config 自动加载，project name = event-gated-adaptive-horizon
- Cron: 无活跃 cron（reconcile_crons 返回 0）

### 3. 📊 当前状态
Session #25 刚完成初始化。Registry 显示 2 个 RUNNING 实验，但状态检查 Worker 确认两者均已产出 metrics.jsonl + latest.pt checkpoint，大概率已完成：

- **exp_097_cheetah_008d_s3** (RUNNING, cuda:0, PID 3794): C1 trigger seed 3，Cheetah 008d config。当前 onset rate 2/3（s0 ✓, s1 ✗, s2 ✓）。ROADMAP 显示训练时 45K 有 onset 后 self-corrected。
- **exp_100_walker_008a_s1** (RUNNING, cuda:1, PID 5591): C3 Walker 008a seed 1，trained dt_emb unexposed to dt>1，预期无 CIVO。

**Workers 运行中（3 个，MCP 断连前 spawn）**:
1. `worker_check_exp_097_100_status_20260526T075041` — 检查两个实验完成状态+提取 metrics（turn 19，正在提取 metrics）
2. `worker_analysis_cheetah-rssm-v3-trained_20260526T074545` — Cheetah RSSM v3 trained 分析（turn 13，卡在 CUDA 设备问题）
3. `worker_analysis_rssm_v3_cheetah_20260526T074729` — Cheetah RSSM v3 分析（turn 30，等脚本输出）

**已向 Director 发送 session-start 汇报**（告知正在检查实验状态，等待 Worker 回调）。

### 4. 📋 待办
- Worker `check_exp_097_100_status` 回调 → 读取 metrics，update_registry 到 DONE（填 conclusion/metrics/checkpoint_path），刷新 report.md，向 Director 汇报结果
  - exp_097: 如果 onset → onset rate 变 3/4（systematic），如果 no onset → 2/4（需讨论）。注意 45K onset + self-correction 的分类
  - exp_100: 如果 no CIVO → C3 Walker 008a 2-seed 闭合（与 s0 + s3 合计）；如果 CIVO → 异常，需诊断
- RSSM v3 Workers 回调 → 合并 Cheetah + Walker RSSM 数字，替换论文旧 2.78× 数字
- 所有分析完成 → 通知 Paper Agent 更新论文数字 + C6 叙事
- 实验全部 DONE + 分析完 → 数据锁定，准备 ICML 投稿

### 5. 🎯 战略上下文
- **核心结论**: trained dt_embedding 是 CIVO 的必要条件（在 multi-joint locomotion 中）。frozen/removed dt_emb 可稳健阻止
- **C6 claim (mitigation)**: 已 CONFIRMED（D153，4/4 current code），旧 008e_v3 CIVO 由参数路由 bug（gate_max_dt=8）导致
- **Cheetah onset rate**: 当前 2/3（s0 NVE=4.1× ✓, s1 NVE=0.517 ✗, s2 NVE=138.7× ✓）。exp_097 (s3) 完成后确定最终 onset rate（n=4）
- **D156 措辞**: trained dt_emb 是 CIVO 必要条件但非充分条件，onset 具有随机性
- **NVE 诊断标准（D155）**: 三维组合——NVE_peak > τ + 持续 ≥2 eval 点 + 时序因果。τ=1.5×（AUROC=0.989, N=61）
- **易错点**:
  - Cheetah baseline eval (~448) vs Walker (~930)，NVE 分母不同，不要混用
  - exp_097 在 45K 有 onset 后 self-corrected，分类为 onset_self_correcting，需按 D155 三维标准判定
  - MCP 工具断连，新 session 需重新加载工具。3 个 Worker 是前 session spawn 的，回调可能需要手动处理
  - 论文已 7 页正文，数据锁定很紧，新数据只更新表格数字，不改结构
