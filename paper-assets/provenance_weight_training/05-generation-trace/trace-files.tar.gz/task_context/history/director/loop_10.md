---
loop: 10
reason: max_messages
updated: '2026-05-16T14:25:16+00:00'
---

### 1. 🔴 硬约束 / 红线
- westd-47453 GPU: cuda:0/1/2/3 | westd-41312 GPU: cuda:0/1/2/3 — 仅限这 8 张卡，不得使用其他项目 GPU
- random_reweight_v2 脚本必须用 WANDB_MODE=disabled（不是 offline），output_dir 必须在数据盘 — 三次失败教训（磁盘满+OOM killer）
- threshold_q07 有 LR 中断（optimizer 未保存导致 warm restart），如 PPL 异常需从零重跑，不能直接用结果
- Llama-3B 实验 lr=5e-5 偏高（典型 1-2e-5），跨模型验证只看相对排序，不做绝对比较
- submit_training_job 前 CUDA_VISIBLE_DEVICES 必须设正确值（code_prep 阶段用 -1 占位，submit 时替换）

### 2. 🖥️ 基础设施快照
- **westd-47453**: connect.westd.seetacloud.com, root, /root/provenance_weight_training
- **westd-41312**: connect.westd.seetacloud.com, root, /root/provenance_weight_training
- 两台均为 4× RTX PRO 6000 96GB，aml-train 镜像（conda base 环境，python 在 /root/miniconda3/bin/python）
- HF_HOME: /root/autodl-tmp/.hf_cache（根分区仅 30GB，大文件必须放 /root/autodl-tmp/）
- W&B: 未配置（实验用 WANDB_MODE=disabled）
- 模型: Qwen3-0.6B 和 Llama-3.2-3B（路径在各服务器 /root/autodl-tmp/ 下）
- 数据: scored_data_40.jsonl (ρ=0.4), scored_data_60.jsonl (ρ=0.6), scored_data_20.jsonl (ρ=0.2) 在 /root/provenance_weight_training/data/ 下
- 活跃进程: 8 个训练进程分布在两台服务器，具体 PID/tmux 需 SSH 确认（Agent session 刚重置）

### 3. 📊 当前状态
**刚做完**：响应系统催促 → 派 Agent 3 项进度检查 + 3 项 CPU 分析任务 + Reviewer 结构性审查 → D055 决策（Claim 3 降级 + random_reweight 优先级提升 + GPU 队列调整）→ ROADMAP 更新 → Paper Agent 通知 framing 调整。但 Agent session 在处理这些消息前就到了硬限，**消息未被处理**。

**RUNNING（8 GPU 满载）**：
- westd-47453: threshold_q07 (cuda:0), rho02_uniform (cuda:1), batch_adaptive_tau_rho04 (cuda:2), threshold_q03 (cuda:3)
- westd-41312: llama3b_uniform (cuda:0), llama3b_adaptive (cuda:1), hybrid_rho04 (cuda:2), hybrid_rho06 (cuda:3)

**PREPARING**: bs8_auto_nmin, batch_adaptive_tau_rho06, rho02_adaptive_tau09, batchsize16_nmin8, grid_b0_2

**等待中**：Agent 重置后需重新派发所有任务（进度检查 + CPU 分析）。Worker 回调可能丢失。

### 4. 📋 待办（条件触发式）
- Agent 重置完成 → 立即派发：(1) 全服务器 8 实验进度检查；(2) CPU 分析三件套（b* 轨迹 / binding 跨 ρ 对比 / 收敛速度）；(3) random_reweight_v2 脚本确认
- threshold_q07 完成 → cuda:0 给 **random_reweight_v2**（致命缺口，最高优先级，不是 batch_adaptive_tau_rho06）
- rho02_uniform 完成 → cuda:1 给 rho02_adaptive_tau09（Claim 3 第三验证点）
- batch_adaptive_tau_rho04 完成 → cuda:2 给 batch_adaptive_tau_rho06（Plan B ρ=0.6，最高期望值实验）
- threshold_q03 完成 → cuda:3 给 bs8_auto_nmin（Plan A 验证）
- hybrid_rho04/rho06 完成 → post-hoc eval + registry 更新
- random_reweight_v2 + rho02 + threshold 数据齐全 → 派 Paper Agent 统一 Patch
- Plan B ρ=0.6 正向（PPL < 17.730）→ Claim 3 大幅加强，通知 Paper Agent 升级表述
- Plan B ρ=0.6 负向 → 不影响，fixed τ 结果不变

### 5. 🎯 战略上下文
- **投稿目标**: EMNLP 2026 ARR May 25（9 天），D054 定位为 focused empirical study with method proposal
- **决策链**: D019(MVP pass) → D029(ESS-only退化) → D035(τ sweep) → D050(grid-best=b0.3) → D051(detect_remove confound) → D052/D053(Claim 3 reframe proportion-agnostic) → D054(narrative: empirical study) → D055(Reviewer弹药评估+优先级调整)
- **最容易判断错的事**：
  1. random_reweight_v2 的 GPU 优先级 — 它是防御性必要条件（论文唯一可被一击致命的缺口），必须排在 Plan B ρ=0.6 前面
  2. Claim 3 的 τ=1-ρ/2 公式只有 2 个数据点，零自由度 — 论文中定位为 "practical guideline" 而非 "validated rule"，核心防线是 "default τ=0.8 works out-of-the-box"
  3. detect_remove PPL=17.29 远优于 adaptive — 这是 eval confound（eval_holdout 纯 human 数据），不是真实优势。叙事已转为 "adaptive 无需 threshold calibration"
  4. bs=8 负向结果根因是 n_min=2 显式传入覆盖了 auto n_min=4 — bs8_auto_nmin 用自动 n_min 验证修复
  5. ρ=0.6 capture ratio 仅 58% — 需在 limitations 诚实讨论，不能回避
