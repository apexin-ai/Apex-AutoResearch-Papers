---
loop: 11
reason: max_messages
updated: '2026-05-16T18:46:41+00:00'
---

### 1. 🔴 硬约束 / 红线
- GPU 白名单：westd-47453 cuda:0-3 + westd-41312 cuda:0-3（共 8 张，项目独占）
- WANDB_MODE=disabled（不是 offline！offline 写 ~150MB 到根分区导致磁盘满崩溃）
- 脚本禁止 --use_wandb flag（pretrain_weighted.py 已移除该参数）
- output_dir 必须在数据盘（`/root/autodl-tmp/provenance_weight_training/output/models/`，通过 symlink `/root/provenance_weight_training/output` 访问）
- CUDA_VISIBLE_DEVICES=-1 是 code_prep 占位符，submit 时替换为实际 GPU 号
- random_reweight_v2_seed42 是 P0 致命缺口实验，threshold_q07 完成后 **必须** 立即分配 47453:cuda:0

### 2. 🖥️ 基础设施快照
- 服务器：westd-47453 (4× RTX PRO 6000 96G) + westd-41312 (4× RTX PRO 6000 96G)
- 工作目录：`/root/provenance_weight_training/`（两台服务器相同）
- `/root/provenance_weight_training/output` → symlink → `/root/autodl-tmp/provenance_weight_training/output`
- Python：`/root/miniconda3/bin/python`（conda base 环境，不用 venv）
- 模型：Qwen3-0.6B（主实验）+ Llama-3.2-3B（跨模型验证，41312 上）
- 数据：`/root/provenance_weight_training/data/scored_data.jsonl`（ρ=0.4）、`scored_data_60.jsonl`（ρ=0.6）
- 无 wandb，无 HF cache 需求（模型已本地化）

### 3. 📊 当前状态
**刚做完**：paper_framing.md 全部 5 处 D056 数据修正、ROADMAP 更新、Paper Agent 2 轮 Patch（Claim 1 加强 + Claim 3 ESS 结构解释 + scope 收窄 + 攻击面防御）、batchsize16/grid_b0_2 审批通过 QUEUED。

**RUNNING (8 GPU)**：
| 实验 | 服务器:GPU | 预估剩余 |
|------|-----------|---------|
| threshold_q07_seed42 | 47453:0 | 即将完成（88.7%→现在应 95%+） |
| rho02_uniform_seed42 | 47453:1 | ~4h |
| batch_adaptive_tau_rho04 | 47453:2 | ~6h |
| threshold_q03_seed42 | 47453:3 | ~6h |
| llama3b_uniform | 41312:0 | ~20h |
| llama3b_adaptive | 41312:1 | ~20h |
| hybrid_rho04 | 41312:2 | ~5h |
| hybrid_rho06 | 41312:3 | ~5h |

**QUEUED/PREPARING**：random_reweight_v2 (PREPARING, 47453:0)、bs8_auto_nmin (PREPARING, 47453:3)、batch_adaptive_tau_rho06 (PREPARING, 47453:2)、rho02_adaptive_tau09 (PREPARING, 47453:1)、batchsize16_nmin8 (QUEUED, 41312:2)、grid_b0_2 (QUEUED, 41312:3)

**等待中**：Reviewer 覆盖率补强建议（已 post_to_reviewer 但未收到回复）；Agent ablation-summary-csv Worker 完成但结果未消化（Agent 连续 500 error + 硬限）。

### 4. 📋 待办（条件触发式）
- threshold_q07 完成（47453:cuda:0 内存回落）→ 检查最终 PPL（⚠️ LR 中断风险，resume 训练可能 PPL 异常）→ `director_allocate_gpus("random_reweight_v2_seed42", "westd-47453", gpu_ids=["cuda:0"])` → 通知 Agent 启动
- hybrid_rho04/rho06 完成 → Agent 跑 post-hoc eval 脚本（已就绪） → 41312:2/3 释放 → `director_allocate_gpus("batchsize16_nmin8_seed42", "westd-41312", gpu_ids=["cuda:2"])` + `director_allocate_gpus("grid_b0_2_seed42", "westd-41312", gpu_ids=["cuda:3"])`
- rho02_uniform 完成 → allocate rho02_adaptive_tau09 到 47453:1
- threshold_q03 完成 → allocate bs8_auto_nmin 到 47453:3
- batch_adaptive_tau_rho04 完成 → allocate batch_adaptive_tau_rho06 到 47453:2
- Reviewer 覆盖率建议回复 → 评估并派 Agent 执行零 GPU 补强分析
- ρ=0.2 实验（rho02_uniform + rho02_adaptive）完成 → Claim 3 可从 ★★☆☆☆ 升至 ★★★☆☆（3 点 ρ 趋势）

### 5. 🎯 战略上下文
- **投稿目标**：EMNLP 2026 ARR May 25（~8 天）
- **D056**：eval checkpoint 数据污染已清除，修正后 Claim 1 大幅加强（ESS ratio 从 2.5× 升至 5×），paper_framing 和论文 .tex 已全部对齐
- **致命缺口**：random_reweight_v2（detector signal load-bearing 验证）——如果 random weights ≈ adaptive，整个 provenance 叙事崩塌。这是投稿前必须完成的实验
- **coverage matrix**：Claim 1 = 41.7%, Claim 3 = 40%，总覆盖 47.1%。正在跑的实验（llama3b, random_reweight, ρ=0.2）完成后覆盖率会显著提升
- **易错点**：(1) hybrid 进度曾 2 次被误报（Agent 读 eval 进度条当训练进度），核实时用 `step_metrics.jsonl tail` 不要信 tqdm；(2) Agent 本 session 连续 3 次撞硬限/500 error，新 session 派任务后注意确认收到；(3) threshold_q07 有 LR 中断风险（训练中途 resume），PPL 可能异常——异常时不影响 GPU 分配决策（仍给 random_reweight_v2），但需在 registry 标注
- **论文状态**：11 页，编译通过，无实际 figure（全是文字描述占位），figure 整合是 Paper Agent 下一步任务
- **Claim 3 叙事升级**：Reviewer 给出结构性解释（ESS 主导 61% → ρ-independence 是结构必然），已写入 paper_framing.md 和 discussion.tex。scope 从 "proportion-agnostic" 收窄为 "proportion-robust within tested range"
