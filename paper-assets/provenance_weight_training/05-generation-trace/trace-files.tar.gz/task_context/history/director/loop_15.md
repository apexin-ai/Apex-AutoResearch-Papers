---
loop: 15
reason: max_messages
updated: '2026-05-21T04:01:31+00:00'
---

### 1. 🔴 硬约束 / 红线
- 本项目 GPU 白名单：westd-41312 的 cuda:0/1/2/3（4 张卡）。禁止使用其他服务器或 GPU
- **禁止使用 `--save_only_model`**（M051 教训：checkpoint 不含 optimizer state，resume 后 Adam 从零初始化导致模型退化）
- **禁止使用 `--eval_data_path` / `--eval_steps`**（M050 教训：inline eval 每 500 步耗时 ~43min，导致训练 timeout 被 kill）
- 所有 eval 结果必须存到 `eval_results/` 目录（不是 `eval/`），否则与 registry pipeline 不一致
- τ=0.8 seed42 的 resume 版本（adaptive_fix_seed42）有已知 resume artifact（M049），OOD 数据不可引用——只用 from-scratch 版本
- eval_perplexity.py 参数：`--checkpoint_paths`（不是 --model_path），`--data_path`（不是 --eval_data）

### 2. 🖥️ 基础设施快照
- 服务器：westd-41312（connect.westd.seetacloud.com），工作目录 `/root/provenance_weight_training`
- Python：`/root/miniconda3/bin/python`（conda base 环境，不是 venv）
- 模型：Qwen3-0.6B（主实验）+ Qwen3-1.7B（scaling 实验）
- 数据：`/root/provenance_weight_training/data/`（holdout_data.jsonl, owt_eval.jsonl, wiki_eval.jsonl）
- Checkpoint 目录：`/root/provenance_weight_training/checkpoints/{exp_id}/`
- Eval 输出：`/root/provenance_weight_training/eval_results/{exp_id}/`
- 无 W&B 配置，无 HF cache 需求（模型已在本地）

### 3. 📊 当前状态
**刚做完**：Reviewer 发现 `--save_only_model` + resume 导致 D110 和 gpt2_seed123 结果作废（M051）。已派 Agent 重跑 _v2 版本并做全局 resume 审计。

**RUNNING 实验**（3 个）：
- `adaptive_tau08_scratch_seed42_v2`（D110 重跑，cuda:0）— 从头训练 ~3.7h，去掉 --save_only_model 和 inline eval
- `gpt2_adaptive_seed123_v2`（cuda:1）— 从头重跑，同上
- `gpt2_adaptive_seed456`（cuda:3）— 从头训练（非 resume，不受影响），审计时 82%，ETA ~42min，应已完成或即将完成

**等待中**：
- Agent 正在处理重跑指令 + 追加的 10 个 resume 实验 eval_checkpoint 来源审计
- gpt2_seed456 完成后需跑 holdout eval
- D110 _v2 完成后需跑 holdout + OOD (OWT + Wiki) eval → 升级 τ=0.8 OOD 到 3-seed from-scratch
- Round 7 审稿报告未回

### 4. 📋 待办
- gpt2_seed456 训练完成 → holdout eval → 更新 registry → GPT-2 detector 3-seed negative 确认
- D110 _v2 训练完成 → holdout + OWT + Wiki eval → 更新 registry → τ=0.8 OOD 升级 3-seed from-scratch → 派 Paper Agent patch 论文（"2 from-scratch seeds" → "3 from-scratch seeds"）
- gpt2_seed123 _v2 训练完成 → holdout eval → GPT-2 detector 2nd seed 确认
- 10 个 resume 实验审计结果回来 → 如有 final checkpoint eval 的，评估是否影响论文数据
- D111 detector ablation 全部 3-seed 完成后 → 派 Paper Agent 更新 appendix detector ablation table
- 所有实验完成 + 论文更新后 → 考虑 submit_paper_to_review（Round 8）

### 5. 🎯 战略上下文
- **DDL**：EMNLP 2026 ARR May 25（~4 天）
- **核心 story**：dual-constrained adaptive b*（α_eff + ESS）用于 contamination-aware reweighting。τ=0.7 推荐默认（holdout + OOD 双赢），τ=0.8 holdout 更好但 OOD-neutral
- **1.7B scaling**（D112 已定稿）：3-seed 确认 "scales without degradation, benefit diminishes"。Holdout Δ=-0.013, OWT Δ=-0.008, Wiki Δ=+0.013（noise）
- **Detector ablation**（D111）：TF-IDF（calibrated, AUC=0.939）成功；GPT-2（uncalibrated, AUC=0.913）和 N-gram（AUC=0.73）均 negative。关键发现：calibration > AUC
- **易错点**：
  1. 不要混用 resume 版和 from-scratch 版的 OOD 数据——seed42 resume 有 artifact（M049），OOD 数据 (+0.049/+0.114) 是假的
  2. 论文中 τ=0.8 OOD 当前写 "2 from-scratch seeds"，D110 _v2 完成后才能升到 3-seed
  3. ngram_seed456 已决定跳过（2-seed variance <0.003 已足够 conclusive）
  4. 决策 D112 已拍板不跑 1.7B τ=0.7（seed456 Wiki Δ=-0.006 < +0.020 阈值，不值得）
