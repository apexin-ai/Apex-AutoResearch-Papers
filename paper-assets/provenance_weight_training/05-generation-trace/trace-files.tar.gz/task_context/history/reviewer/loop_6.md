---
loop: 6
reason: max_wall_time
updated: '2026-05-15T00:55:02+00:00'
---

### 1. 🔴 硬约束 / 红线
- 训练用 GPU 0 和 GPU 1（registry 中所有训练实验分配在 cuda:0 或 cuda:1）
- eval 可临时用 GPU 2（轻量只读，目前无 constraints.yaml 硬限制，但训练不可越界）
- Drayson 差异化**不能**写"Drayson assumes known contamination proportions"——原文明确说 "does not assume access to the values of the mixing coefficients"。正确差异点是 validation-set tuning vs batch-adaptive derivation
- registry b_star 统计量（adaptive_fix 三个实验）包含 eval checkpoint 污染，真实值见 artifacts/bstar_distribution_analysis.md（mean≈1.4 非 0.7）

### 2. 🖥️ 基础设施快照
- 服务器：westd-47453(root)，工作目录 /root/provenance_weight_training
- Python：/root/miniconda3/bin/python（conda base 环境）
- 模型：/root/provenance_weight_training/models/Qwen/Qwen3-0.6B
- 训练数据：/root/provenance_weight_training/data/scored_data.jsonl (371,499 docs, 40% synthetic)
- Eval 数据：/root/provenance_weight_training/data/human/eval_holdout.jsonl (4.08M tokens)
- Eval 结果：/root/provenance_weight_training/output/eval_results/*.json
- WANDB_MODE=disabled（所有实验）
- 活跃进程（截至 handoff）：
  - PID 152488, GPU 0: grid_b2_0_seed456（训练中）
  - PID 145062, GPU 1: grid_b0_5_seed456（训练中，这是 MVP 关键实验）
- 本地 workspace：/home/ubuntu/.agent-ml-research-idea_gen_0509_10/projects/provenance_weight_training/

### 3. 📊 当前状态
刚审完 grid_b1_0_seed456 + grid_b1_5_seed456（PPL=17.682/17.709，符合预期单调递增）。

Registry RUNNING:
- grid_b0_5_seed456 (cuda:1) — **MVP 关键**：这个 eval_ppl 决定 grid-best seed456，进而决定 MVP aggregate ratio
- grid_b2_0_seed456 (cuda:0) — 补全 grid 曲线

QUEUED（未启动）：grid_b3_0_seed456, grid_b5_0_seed456

已准备未提交：run_grid_b_low_seed{42,123,456}.sh（b=0.1/0.2/0.3 扩展搜索，在项目根目录）

### 4. 📋 待办
- grid_b0_5_seed456 完成 → 最关键审查：eval_ppl 是否 < 17.650（若是则 aggregate MVP ratio < 90%，触发 Path B 叙事调整）。参考值：seed42=17.651, seed123=17.638
- grid_b2_0_seed456 完成 → 核实 PPL 单调性（应 > 17.709）
- 所有 seed456 grid 出齐 → 核实完整 MVP 判定：adaptive_fix_seed456 PPL=17.66 vs grid-best seed456。计算 Δ_adaptive/Δ_grid ratio
- Agent 更新 registry b_star 统计量 → 核对是否用了排除 eval 记录后的值（mean≈1.4, median≈0.88）
- Agent 更新 literature_map.yaml → 核对 arXiv 2602.16065 是否已添加、yi_2025 作者是否修正

### 5. 🎯 战略上下文
- **MVP 判定处于边缘**：aggregate ratio 95.6%（2 seeds），但 seed456 的 grid-best 可能使其降到 85-90%。若 grid_b0_5_seed456 PPL ≈ 17.638（与 seed123 持平），则 Δ_grid=0.062, Δ_adaptive=0.040, ratio=64.5% → FAIL。若 PPL ≈ 17.660, ratio=100% → PASS。**这是全项目最关键的单一数据点。**
- 核心决策链：D012(n_min fix) → D013(Drayson novelty) → D014(framing) → D015(extreme b*) → D016-18(v1→v2 clarification)
- paper_framing.md 已修正 Drayson 表述（本轮我推动的），差异化核心是"validation-based tuning vs batch-adaptive derivation"
- bstar_distribution_analysis 揭示了 eval checkpoint 污染（已修代码），但 registry 旧值未更新。下一个"你"在审查引用 b* 统计量的文档时，注意区分旧值（含 eval）和新值（排除 eval）
- 易错点：mvp_analysis_summary.md §4 的 CV=137% 结论是错的（eval 污染导致），别被误导
