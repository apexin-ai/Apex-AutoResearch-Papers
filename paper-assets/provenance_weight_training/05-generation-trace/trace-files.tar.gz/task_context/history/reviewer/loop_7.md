---
loop: 7
reason: max_wall_time
updated: '2026-05-15T10:06:52+00:00'
---

### 1. 🔴 硬约束 / 红线
- GPU 白名单：cuda:0/1/2/3（westd-47453 项目配置，越界即 CRITICAL）
- Checkpoint resume 已确认导致系统性 PPL 降级（+0.15~0.25）——**不要再用 resume 修复 interrupted training**，必须从头重跑
- seed456 b=2.0/3.0/5.0 已 invalidated（D026），论文 Grid sweep 仅用 seed42+seed123 的 2-seed 数据
- τ 不能再声称"theoretically principled"——arXiv 2602.16065 的 α 是已知设计参数，τ 定位为 "empirical hyperparameter with theoretical motivation"（D025）
- grid_b_low 旧脚本（根目录 `run_grid_b_low_seed42.sh`）**没有 --bf16 且含 inline eval**，正确版本在 `training/run_grid_b_low_seed42.sh`

### 2. 🖥️ 基础设施快照
- 服务器：westd-47453(root)，工作目录 `/root/provenance_weight_training`
- Python：`/root/miniconda3/bin/python`，conda env = base
- 模型：`/root/provenance_weight_training/models/Qwen/Qwen3-0.6B`
- 数据：`data/scored_data.jsonl`（371K docs, 40% synthetic），eval: `data/human/eval_holdout.jsonl`（8477 docs, 4.08M tokens）
- Post-hoc eval 脚本：`eval_perplexity.py`（sliding window stride=1024, fp16, max_docs=5000）
- W&B：DISABLED（所有实验 WANDB_MODE=disabled）
- HF cache：`/root/autodl-tmp/.hf_cache`
- 活跃进程（截至 handoff）：ess_only_seed42 cuda:1, golden_ratio_seed42 cuda:0, nmin1_seed42 cuda:2, tau_06_seed42 cuda:3（均 ~3.5h，ETA ~13:00-13:30 UTC）

### 3. 📊 当前状态
**刚完成的审查**：
- experiment_summary.md 更新（seed456 artifact 标注）✓
- literature_scan_results.md（35+论文，Wang et al. 2602.16065 已补入 literature_map）✓
- grid_b2_0/b3_0/b5_0 seed456 post-hoc eval → 全部确认 checkpoint resume artifact（D026）
- τ theory audit（arXiv 2602.16065 的 α 是已知量，不支持 Claim 3 "proportion-free"）→ D025

**Registry RUNNING**：ess_only_seed42, golden_ratio_seed42, nmin1_seed42, tau_06_seed42
**Registry PREPARING**：tau_05/07/09/095_seed42（τ sweep 剩余 4 组）
**Registry QUEUED**：detector_modernbert（P1）

**下一批排期**（~13:30 后 GPU 释放）：τ sweep 剩余 4 值可 4 GPU 并行（~3.6h），之后 n_min=4 + batchsize=8/16

### 4. 📋 待办
- ess_only_seed42 完成 → **最关键审查**：如果 ess_only PPL ≥ adaptive_fix (17.65)，α_eff 独立价值确认（D023 Key Risk #1 解除）；如果 ess_only < adaptive_fix，论文 framing 需要重大调整
- golden_ratio_seed42 完成 → 对比 adaptive_fix：golden_ratio 是 oracle（需已知比例），adaptive 应接近或超越
- nmin1_seed42 完成 → 检查是否 over-downweight（n_min=1 无实质 ESS 约束，b* 可能极端偏高）
- tau_06_seed42 完成 → 首个 τ sweep 数据点，后续 4 组并行提交
- 4 组 τ sweep 全部完成 → 验证 PPL variance < 0.05 across τ range（Claim 3 实证支撑）
- GPU 空闲 > 30min → 立即向 Director 报告，建议提交下一批
- paper_framing.md 写作审查请求 → 按 5.1/5.2 维度审，特别注意 Claim 3 表述是否已降级

### 5. 🎯 战略上下文
**决策链**：D019(MVP pass) → D020(Dream weak reject) → D021(α_eff decorative?) → D022(overcorrection) → D023(dual-constraint restored) → D024(Llama→P1) → D025(τ empirical HP) → D026(checkpoint artifact, 2-seed) → D027(grid_b_low deprioritized)

**论文三个 Claim**：
1. Dual-constrained adaptive b*（α_eff+ESS）— ESS-only baseline 是决定性实验
2. 免调参匹配 Grid-best — 已有数据支撑（91% recovery）
3. Unknown proportion setting — **最薄弱**，理论基础已动摇（D025），仅靠 τ sweep 实证

**易错点**：
- cron 监控会误判实验 failed（无 sentinel/W&B 的实验被报 "process dead" 但 GPU 实际在跑）——先 nvidia-smi 确认再下结论
- experiment_summary.md 的 "91.0%" 是 mean-of-ratios，论文应用 ratio-of-means (89.9%)——ROADMAP 已标注但 summary 未改
- `compute_coverage_matrix` 工具返回空（YAML 格式不兼容），需手动评估覆盖率
- 两个同名实验 tau_0.6_seed42 (QUEUED, 废弃) vs tau_06_seed42 (RUNNING, 正式)——点号命名已标废弃
