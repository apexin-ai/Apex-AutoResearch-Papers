---
loop: 17
reason: idle_timeout
updated: '2026-05-17T22:32:59+00:00'
---

### 1. 🔴 硬约束 / 红线
- GPU 白名单：westd-30476 cuda:0-3, westd-41312 cuda:0-3。其他设备/服务器禁止使用
- westd-47453 已下线，不要尝试连接
- output_dir 必须用 `/root/autodl-tmp/` 持久卷（30476），不要写 /root/ 临时盘
- submit_training_job 命令必须自带环境激活（`source /root/miniconda3/bin/activate && ...`），不假设 .venv
- transformers 版本锁定 4.57.x（4.57.6 有 bug 已降级，不要升回去）
- Claim 3 scope 已限定 ρ≥0.4, τ∈[0.7,0.8]（D068），不要在 ρ=0.2 上继续投资源

### 2. 🖥️ 基础设施快照
- **westd-30476**: 4×RTX PRO 6000 96G, 工作目录 `/root/autodl-tmp/provenance_weight_training`
  - Python: `/root/miniconda3/bin/python`
  - Log 目录: `/root/runs/provenance_weight_training/`
- **westd-41312**: 4×RTX PRO 6000 96G, 同上路径布局
  - 上一批实验（llama3b_uniform/adaptive, grid_b0_2, batchsize16_nmin8）已全部完成
- 模型: Qwen3-0.6B（主实验），Llama-3.2-3B（跨模型已结束，结论 neutral）
- W&B: 项目内实验均有 wandb tracking
- 活跃进程:
  - grid_b0_3_seed456_r2: PID 54779, westd-30476:cuda:0
  - batchsize16_nmin8_r3: PID 48891, westd-30476:cuda:3（cron 监控中）
  - ess_only_seed456_r2: PID 133526（⚠️ cron 说 running 但 registry=failed，需核实）
  - ess_only_seed123_r2: PID 133444（⚠️ 同上冲突）

### 3. 📊 当前状态
**刚做完**: 前一轮 8 GPU 满载实验大部分已完成——llama3b 跨模型结论 neutral(D067)、batch-adaptive τ 彻底关闭(D070)、coupling rule bs=8 验证 success、random baseline 确认 signal load-bearing(D064)。

**当前 registry**:
- 107 total: 104 DONE (54 success / 7 negative / 28 failed / killed), 2 RUNNING, 1 ANALYZING
- RUNNING: grid_b0_3_seed456_r2 (Claim 2 cross-seed), batchsize16_nmin8_r3 (coupling rule bs=16)
- ANALYZING: rho02_adaptive_tau08_seed42 (Claim 3 ρ=0.2 边界最后一试)

**⚠️ 关键问题**: westd-41312 的 4 GPU 全部空闲，westd-30476 的 cuda:1 和 cuda:2 也可能空闲。8 张卡只跑 2 个实验 = **严重 under-saturated**。需要立即填满。

**等待中**:
- batchsize16_nmin8_r3 和 grid_b0_3_seed456_r2 的 cron 完成回调
- rho02_adaptive_tau08_seed42 处于 ANALYZING 但 metrics 为空——需要 Worker 去读 log 提取结果
- ess_only crons 与 registry 状态冲突需要排查

### 4. 📋 待办（条件触发式）
- **立即**: rho02_adaptive_tau08_seed42 ANALYZING + metrics 空 → spawn Worker SSH 读 log 提取 PPL → 更新 registry
- **立即**: westd-41312 4 GPU 空闲 → 查 experiment_plan.yaml 未跑的格子 → 批量提交（优先 Claim 2 cross-seed: adaptive_fix_seed123, adaptive_fix_seed456, grid_b0_3_seed123）
- **立即**: ess_only_seed456_r2 / ess_only_seed123_r2 cron 说 running 但 registry=failed → spawn Worker SSH 查 PID 存活 → 若真 running 则修 registry 为 RUNNING，若 orphan 则 kill + 清 cron
- grid_b0_3_seed456_r2 cron 回调 → eval → 结果与 grid_b0_3_seed42(17.640) 对比 → 更新 Claim 2 证据
- batchsize16_nmin8_r3 cron 回调 → eval → 若 PPL ≈ bs4 adaptive → coupling rule 在 bs=16 确认 → Method 完整
- 所有 running 实验完成后 → Paper Agent 5 pending patches 可执行 → 推论文

### 5. 🎯 战略上下文
- **投稿**: EMNLP 2026 ARR May 25，还有 **8 天**。Paper 8 页 + appendix 框架已有，5 个 patch 等数据
- **核心方法**: Dual-constrained adaptive b*（α_eff 质量下界 + ESS 稳定上界 → 最小干预准则）
- **Claim 1** (dual > ESS-only): ★★★★★ 证据充分（3 seeds + random baseline）
- **Claim 2** (adaptive ≈ grid): ★★★☆☆ **瓶颈在跨 seed**——seed42 单点 Δ=0.013，reviewer 会质疑 cherry-pick。grid 曲线平坦性是有利叙事（"合理区间内差异可忽略"）但需要 seed123/456 数据
- **Claim 3** (proportion-robust): ★★☆☆☆ scope 已收窄到 ρ≥0.4, τ∈[0.7,0.8]。ρ=0.2 negative 放 Discussion

**易错点**:
- 不要把 Llama-3.2-3B 结果当成 negative——D067 已修正为 "neutral"，放 Discussion
- grid 曲线平坦性 [0.2-0.5] 差异仅 0.011，这是**好事**（strengthens "adaptive 落在平坦区间"叙事）
- 30476 曾出现 SIGKILL 事件（非 OOM），如果再出现先查 cgroup memory.events 的 oom_kill 计数器
- Worker 池当前 = 0，严重低于红线（≥2）。下一个 session 启动后必须立即批量 spawn
