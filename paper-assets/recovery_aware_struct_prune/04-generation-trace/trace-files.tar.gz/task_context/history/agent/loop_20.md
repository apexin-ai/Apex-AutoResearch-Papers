---
loop: 20
reason: idle_timeout
updated: '2026-05-21T07:48:47+00:00'
---

### 1. 🔴 硬约束 / 红线
- GPU 白名单: cuda:0/1/2/3，服务器 westb-23072 和 westd-29022
- **westd-29022 网络离线**：所有实验命令必须带 `HF_DATASETS_OFFLINE=1 HF_HUB_OFFLINE=1`，否则 HF datasets 发 HEAD 请求导致崩溃（已有 5 次 MBPP eval 因此失败）
- westb 上 SFT RASP 20% 模型路径是 `sft_rasp_20_1p5b`，不是 `sft_rasp_20`（路径错误已导致多次 eval 失败）
- 投稿目标 EMNLP 2026 ARR May 25，**剩 ~4 天**，25% cross-sparsity 数据是关键路径
- submit_training_job 的 command 必须自带环境激活（`source /root/miniconda3/etc/profile.d/conda.sh && conda activate base`）

### 2. 🖥️ 基础设施快照
- **westb-23072**: 2× RTX PRO 6000, 23GB free, 工作目录 `/root/recovery_aware_struct_prune`, Python `/root/miniconda3/bin/python`
- **westd-29022**: 4× RTX PRO 6000, ~21GB free（需清理到 ≥48GB: 删 dense 15G + old ckpt 12G）, 同上路径结构
- 模型/数据: `/root/autodl-tmp/recovery_aware_struct_prune/` 下各 checkpoint
- conda 环境: `source /root/miniconda3/etc/profile.d/conda.sh && conda activate base`
- 活跃进程:
  - westb: eval_math500_sft_standard_25_v2 (PID 62714), eval_gsm8k_grpo_standard_25 (PID 75282)
  - westd: eval_gsm8k_grpo_cka_only_25_v3 (PID 322443, cuda:0), eval_gsm8k_sft_cka_only_25 (PID 329698, cuda:1), eval_gsm8k_sft_random_20 (PID 329770, cuda:2)
- Cron 监控: 5 个活跃 cron 对应上述 5 个 RUNNING 实验

### 3. 📊 当前状态
5 个 eval 实验全部 RUNNING，等待 cron 回调。30 个实验处于 PREPARING（大部分是历史遗留/低优先级）。

**关键实验优先级**:
1. **eval_gsm8k_grpo_cka_only_25_v3** (westd cuda:0) — #1 优先级，cross-sparsity 25% 的最后关键数据点。前两次 v1/v2 因路径错误 failed，v3 用正确 model_path `/root/autodl-tmp/recovery_aware_struct_prune/grpo_cka_only_25`
2. **eval_gsm8k_grpo_standard_25** (westb) — Standard 25% GRPO GSM8K，预期很低（GRPO reward=0.008 near-collapse）
3. **eval_gsm8k_sft_cka_only_25** / **eval_gsm8k_sft_random_20** (westd cuda:1/2) — SFT baseline floors
4. **eval_math500_sft_standard_25_v2** (westb) — MATH-500 补充数据

等待: 全部等 cron 回调，无 Worker 在跑，无 Director 决策 pending。westd cuda:3 空闲。

### 4. 📋 待办（条件触发式）
- eval_gsm8k_grpo_cka_only_25_v3 完成 → 更新 registry + 对比 Standard 25% (51.1%) / RASP 25% (53.15%)。若 CKA-only > Standard，Table 3 cross-sparsity 行完成 → 汇报 Director → 更新论文
- eval_gsm8k_grpo_standard_25 完成 → 记录 GSM8K accuracy（预期极低，reward=0.008），确认 Standard 25% collapse → 与 CKA-only 25% 对比放大 Δ
- eval_gsm8k_sft_cka_only_25 完成 → SFT baseline floor，计算 SFT→GRPO recovery delta
- eval_gsm8k_sft_random_20 完成 → Random 20% SFT floor，Table 2 补充
- 所有 25% eval 完成 → 汇总 cross-sparsity 全景（15%/20%/25%），更新论文 Table 3，向 Director 汇报是否摸到 3.5→4.0 天花板
- westd 磁盘清理（删 dense model 15G + old checkpoint 12G → 释放 ~27GB）—— 在当前实验完成后执行，不要中途操作

### 5. 🎯 战略上下文
- **核心结论**: CKA-only pruning 在 GRPO recovery 上显著优于 Standard（20%: +4.55pp p=0.0009, 15%: +7.20pp p<0.001）。25% 是补强数据点（Standard 已 collapse reward=0.008, CKA-only reward=0.2875）
- **决策链**: D087 否决 claim 升级保持 analysis paper → D090 保留 3-seed mean → D091 驳回 2-seed → D092 15% 三种子完成 → D093 25% 单种子 pilot → D094 Round 2 action matrix → D095 补强实验
- **审稿状态**: Round 3 得分 3.0/5, 34 issues 全部 resolved, 编译通过 ≤8 页。加入 25% 数据后 Reviewer 预期天花板 3.5, 有望 4.0
- **易错点**:
  - westd 离线——忘加 `HF_DATASETS_OFFLINE=1` 是最常见失败原因
  - grpo_cka_only_25 的正确 checkpoint 在根目录 `/root/autodl-tmp/recovery_aware_struct_prune/grpo_cka_only_25`（不是 checkpoint-100 子目录），v1/v2 都因路径问题 failed
  - PREPARING 实验有 30 个但大部分是历史遗留，不要盲目提交——优先看 ROADMAP 近期任务列表
  - CKA scoring stability 已验证（ρ > 0.964），Reviewer 相关质疑可直接用数据回应
