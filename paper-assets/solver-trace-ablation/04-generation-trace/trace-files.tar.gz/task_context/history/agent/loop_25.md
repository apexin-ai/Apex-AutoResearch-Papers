---
loop: 25
reason: idle_timeout
updated: '2026-05-22T18:47:02+00:00'
---

### 1. 🔴 硬约束 / 红线
- 本项目只能用 westd-39279:cuda:0（唯一分配的 GPU）
- 项目处于提交准备阶段，DDL 2026-05-25（剩 3 天）。Reviewer 已 PASS，论文 v10+ 主文 ~7.4 页。**不要改论文内容除非 Director 明确指示**
- 1000-step 系列实验（exec-only-s45-1000step 等）是提交后补充实验，不阻塞提交
- exec-only-s45-1000step 已被 cron 标记 failed（进程崩溃 5 次），诊断 Worker 已派出但尚未回调

### 2. 🖥️ 基础设施快照
- 服务器：westd-39279，GPU: 1×（cuda:0）
- 工作目录：未在本 session SSH 确认（诊断 Worker 正在探查）
- 训练命令模板：`python scripts/train_grpo.py --config configs/exec_only_s45_1000_k4.yaml`
- 日志路径：`/tmp/exec_only_s45_1000_k4.log`
- 模型：Qwen3-4B，数据：`data/train_500_seed42.jsonl`（500 条）
- 磁盘：/autodl-pub 5.3T/7.3T 可用（24%），充裕
- 活跃 Worker：
  - `worker_pipeline_s45-recovery-s46-8b_20260522T020853`（CPU，pipeline 任务，来源不明——可能是上一个 session 派的恢复流水线）
  - `worker_diagnose_exec-only-s45-1000step_20260522T021328`（CPU，诊断任务，等待回调）
- Cron：reconcile 返回 0 条活跃 cron

### 3. 📊 当前状态
本 session 收到 exec-only-s45-1000step 失败的 cron 回调。已派诊断 Worker SSH 读日志，**尚未收到 [WORKER DONE] 回调**。已向 Director 汇报失败情况。

Registry 关键状态：
- DONE: 181（success 73, negative 47, failed 50, killed 11）
- PREPARING: 33（含 exec-only-s46-1000step, d158-llama-sft-s42, d154-8b 系列等）
- QUEUED: 1（exec-only-s45-1000step-k8）
- RUNNING: 0（GPU 空闲）

重复 cron 回调：同一实验的失败通知收到了 2 次，第 2 次已忽略（幂等）。

### 4. 📋 待办
- **诊断 Worker 回调到达** → 读取根因，update_registry 补充 failure_reason 细节，汇报 Director 并建议是否重试
- **Director 决定重试 s45-1000step** → 根据诊断结果修复后用 submit_on_allocated 重新提交到 cuda:0
- **Director 不重试** → 检查 QUEUED 的 exec-only-s45-1000step-k8 和 PREPARING 的 exec-only-s46-1000step，按优先级提交下一个实验到空闲 GPU
- **pipeline Worker 回调到达** → 读取产出，可能已包含 s45 恢复 + s46 + 8B 实验的准备工作
- **提交 DDL 2026-05-25 临近** → 论文已 PASS，关注是否有 ISR 命名决策（待用户回复）和最终编译提交

### 5. 🎯 战略上下文
- **核心结论**：STA 作为 LOO 诊断工具揭示 GRPO 训练中的结构退化和 Goodhart 效应。论文已通过 Reviewer 审查，处于提交就绪状态
- **关键决策链**：D157（Shuffled-ISR 去混淆）→ D158（LLaMA SFT 终止）→ D159（C2 不升级 mechanistic）→ Reviewer PASS
- **易错点**：
  - GPU 空闲是因为实验刚失败，不是遗忘——不要急着提交新实验，先等诊断结果
  - pipeline Worker 可能已经在做恢复工作，新 session 先 get_worker_status 确认两个 Worker 状态再行动，避免重复派发
  - 33 个 PREPARING 实验大多是 D154 8B 系列和其他补充实验，**不阻塞论文提交**
  - exec-only-s43-1000step 之前也反复失败（r2-r6 全 failed），1000-step 系列可能有系统性问题（OOM / 配置 bug），诊断 s45 时注意是否与 s43 同因
