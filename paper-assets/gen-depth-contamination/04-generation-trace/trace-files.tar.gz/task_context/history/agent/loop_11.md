---
loop: 11
reason: idle_timeout
updated: '2026-05-15T15:40:45+00:00'
---

### 1. 🔴 硬约束 / 红线
- GPU 白名单只有 `cuda:0` on `westc-26893`，绝对不碰其他 GPU
- exp-004 用的是 **Qwen2.5-7B BASE**（不是 Instruct），D032 明确决策不中止重启，结果分析时注意 base vs instruct 差异
- Binoculars performer 模型 ID 必须用 `allenai/OLMo-1B-0724-hf`（带 -hf 后缀），原 ID 404——exp-012 脚本已修正但注意别回退
- 论文中 K*=2 限定为 "self-scoring lower bound"（cross-scorer 下 Qwen-cont K*=1），不能 claim universal
- discussion.tex 禁止量化 "70-85% text-intrinsic" 分解——数据不支持精确拆分
- Holm-Bonferroni 结果是 MMLU 8/15（不是 10/15），已 bugfix 确认

### 2. 🖥️ 基础设施快照
- **服务器**: westc-26893（原 autodl-4090d，已更名），1×RTX 4090 D 24GB
- **工作目录**: `/root/autodl-tmp/gen-depth-contamination`
- **Python**: `/root/miniconda3/bin/python`（conda base 环境，非 venv）
- **激活命令**: `source /root/miniconda3/etc/profile.d/conda.sh && conda activate base`
- **模型缓存**: `/root/autodl-tmp/.hf_cache`
- **数据目录**: `data/` (Qwen-RW), `data_exp001_pythia/`, `data_exp002_olmo/`, `data_exp017_qwen_cont/`, `data_exp004_qwen7b/`
- **产出目录**: `artifacts/`
- **活跃进程**: exp-004 (tmux: exp004, PID=exp004, cuda:0) — generation depth 2/5 at 91%, ETA ~03:00 UTC 05-16
- **Cron**: exp_004_7b_crossscale 有 1 个活跃 cron 监控（reconcile 确认 still running）
- **网络**: 需要 `source /etc/network_turbo` + SSL 证书环境变量 + `HF_HUB_DISABLE_XET=1`

### 3. 📊 当前状态
刚完成全部 rebuttal 实验的论文整合（EXP-A/B/C/D/E + K*(θ) 图 全部 ✅），论文编译 18 页 0 critical warnings。

**RUNNING**: exp_004_7b_crossscale — Qwen2.5-7B BASE continuation, C4 5K seeds, scorer=1.5B。Generation depth 2/5 完成 91%，ETA ~03:00 UTC 05-16。这是 FR-4 (≤1.5B 规模限制) 的 rebuttal 实验。

**QUEUED**: exp_012_binary_confidence — DivEye log-PPL + Binoculars ratio vs true depth Spearman ρ。代码准备中，两个 Worker 还在 running：
- `worker_code_exp_012_script_verify` — 验证 exp-012 脚本
- `worker_fix_exp012_bino_performer` — 修复 Binoculars performer 模型 ID (OLMo-1B-0724-hf)

其余 18 个实验全部 DONE/success（0 negative, 0 failed）。

### 4. 📋 待办（条件触发式）
- exp-004 cron 回调到达 → spawn Worker 分析 7B K* 结果 → 若 K*=2 则 claim "K*=2 stable across 1.5B-7B"；若 K*≠2 则走 red-section Framing 提案 → update registry + report.md → 汇报 Director
- exp-004 完成且 GPU 释放 → 立即提交 exp-012（代码已准备，QUEUED 等 GPU）
- exp-012 Worker 回调（脚本验证+模型修复）→ 确认 dry-run 通过 → 更新 registry notes
- exp-012 完成 → 分析 Spearman ρ → 整合论文 → 汇报 Director
- exp-004 + exp-012 全部整合完 → submit_paper_to_review（continue 模式）

### 5. 🎯 战略上下文
**核心结论**: K*=2 across 8 条件（4 模型 × 2 generation modes + 4 decoding configs），θ=0.60 有 K*(θ) 曲线 + Cohen's h 双论证。C3 filtering 确认 binary-ours 最优（Version B）。3 Critical 全解决，Warning 只剩 FR-4 (7B 规模) 在跑。

**决策链要点**: D032 (7B 用 BASE 不重启) → D033 (CI lower bound 定义 K*) → D034 (OBD v2 无适配) → D035 (K* 下标修正) → D036 (Claim 强度维持现状)

**易错点**:
- exp-004 是 7B **BASE** 模型，之前所有 ≤1.5B 实验用的是 **Instruct**，比较时注意 base/instruct 差异可能影响 K*
- Qwen-cont CI lower=0.6015，仅比阈值高 0.0015——如果 7B 结果 marginal，K* 定义需要特别谨慎措辞
- 两个 exp-012 prep Worker 还在 running，下一个 session 先 check 它们的结果再决定是否需要额外修复
- ARR DDL 05-25，当前在 05-15——还有 10 天，但 exp-004 + exp-012 + 论文整合 + 二审迭代需要紧凑排期
