---
loop: 9
reason: max_messages
updated: '2026-05-21T02:55:34+00:00'
---

### 1. 🔴 硬约束 / 红线
- GPU 只能用 rtx5090-4x 的 cuda:0-3（项目配置白名单），bjb2-12179 无 GPU 权限
- Evidence tax 必须用 matched@2048 token budget（D137 硬约束）——mismatched (no-evi@2048 vs with-evi@1024) 会产生截断伪影，D136 就是这么被推翻的
- D136 "方向不稳定" claim 已 INVALIDATED，不要在任何分析或论文中引用
- RSFT tax 在 @1024 可能是可靠的（14B 截断对称 10.8% vs 10.7%），但需要 RSFT s42 with-evi@2048 control 确认（正在跑）
- paper_framing.md 的 LLaMA SFT evidence tax 行标注了 "⚠️ 极不稳定"——等 matched@2048 3-seed 数据齐全后才能定稿
- Qwen evidence tax 也可能受截断影响——已指令 Agent 检查 Qwen with-evi truncation rate，如果 >5% 需要 matched@2048

### 2. 🖥️ 基础设施快照
- 服务器：rtx5090-4x (connect.westd.seetacloud.com:37389)，4× RTX PRO 6000 96GB
- 工作目录：/root/autodl-tmp/faith-evidence-ie/
- Python：/root/miniconda3/bin/python（conda base 环境，不是 venv）
- 模型缓存：/root/autodl-tmp/.hf_cache/
- 数据盘：/root/autodl-tmp/（~114GB 可用）
- bjb2-12179：数据源服务器，无 GPU，SFT adapter 等资产在此（rsync 到 rtx5090-4x）
- 活跃进程：
  - cuda:0: eval_llama_rsft_s42_with_evidence_2048 (PID 70706, ~02:48 UTC 启动)
  - cuda:2: eval_llama_sft_s43_with_evidence_2048 (running)
  - cuda:3: eval_llama_sft_s44_with_evidence_2048 (running)
  - cuda:1: 空闲，Agent 队列中有指令去检查 Qwen truncation 后派活

### 3. 📊 当前状态
刚完成：ROADMAP 全面刷新（14B RSFT D138 + matched@2048 D137 + 清理过期迁移任务），Agent 指令已排队（harvest 14B@2048 + cuda:1 Qwen truncation check + 派活）。

- plan017_14b_rsft_eval_2048：已完成但 registry 未更新（Reviewer warning），metrics.json 已写入远程，Agent 队列中有 harvest 指令
- eval_llama_rsft_s42_with_evidence_2048 (cuda:0)：RSFT with-evi@2048 control，验证 RSFT tax @1024 是否可靠。预期 delta <1pp
- eval_llama_sft_s43_with_evidence_2048 (cuda:2)：matched SFT tax s43
- eval_llama_sft_s44_with_evidence_2048 (cuda:3)：matched SFT tax s44
- Agent 队列 depth=3（旧指令处理中 + 2 worker:done + 我的新指令）

### 4. 📋 待办
- plan017_14b_rsft_eval_2048 harvest 完成 → 对比 14B @2048 vs @1024 ign_f1 delta。delta <1pp 确认 14B tax 可靠；delta >1pp 需要用 @2048 重算
- RSFT s42 with-evi@2048 完成 → 对比 @1024 ign_f1=0.5714。delta <1pp → 所有 RSFT tax @1024 可靠，无需更多 RSFT @2048 实验
- s43 + s44 with-evi@2048 都完成 → 重算 matched@2048 3-seed SFT evidence tax：s42 已知 tax=-4.39pp，合并 3 seed 后确定最终 narrative（"consistent benefit + magnitude instability" vs "consistent large benefit"）
- matched 数据齐全 → 发 Reviewer 系统性审查 evidence tax narrative，然后派 Paper Agent 全面 patch evidence tax 数字
- Qwen truncation check 结果出来 → 如果 >5%，需规划 Qwen matched@2048 系列实验（这会是大工程）
- 所有 evidence tax 定稿后 → 重新 submit_paper_to_review

### 5. 🎯 战略上下文
- 项目目标：EMNLP 2026 Main (ARR July, ~55天)，Round 1 = 3.0 Findings，冲 4.0 Main
- 14B RSFT ign_f1=0.5886 是全项目最高，evidence tax=-4.54pp（强 benefit），截断对称——这是最强结果
- D137 是本轮最重要的方法论修正：with-evi 也受 1024 截断影响（s42 delta=+2.65pp），所有 mismatched tax 都不可信
- 预期 matched@2048 下 LLaMA SFT tax 全部为 negative（evidence consistently helps），但量级差异巨大（s42 -4.39pp，s43 可能 -17pp 因为 s43 no-evi@2048 只有 33.89）
- 新叙事方向：evidence 是 "safety net"——弱 seed/弱模型从 evidence 获益最多。与 1.7B tax=-6.2pp 的 regularization 发现一致
- Cohen's d=2.58 for RSFT vs SFT（LLaMA 8B），统计防御力很强
- 易错点：不要引用 D136 的 "方向不稳定" 数据——那些是 mismatched 伪影。只用 matched@2048 数据
- 易错点：Reviewer 发现 plan017_14b_rsft_eval registry 的 truncated=0 是错的（实际 105），分析前必须确认 registry 已修正
- 易错点：Agent 报告的 GPU 状态可能滞后——Reviewer 交叉检查更可靠
