---
loop: 2
reason: idle_timeout
updated: '2026-05-14T14:20:54+00:00'
---

### 1. 🔴 硬约束 / 红线
- GPU 白名单仅 `cuda:0`（autodl-rtx6000pro），绝对不碰其他卡
- 这是 **API-only 项目**（0 GPU training），pipeline 跑 Qwen3-32B-AWQ 本地推理 + Z3/Python exec，不要误当训练任务
- **禁止双进程启动 pipeline**（memory.md 教训）：submit_on_allocated(tmux) 和 nohup 曾同时启动导致数据损坏。启动前必须确认前一个进程已终止
- DDL: EMNLP 2026 ARR **May 25**（距今 11 天），Day 4 硬截止（May 18）MVP 未 pass → kill
- D007 已决策：**保持 3-way 输出**（FOL 和 Code 都是 True/False/Unknown），不做 closed-world 2-way。审稿人会质疑语义假设差异 vs 推理错误

### 2. 🖥️ 基础设施快照
- 服务器：`autodl-rtx6000pro`，工作目录 `/root/autodl-tmp/crdd`
- Python：`/root/miniconda3/bin/python`（conda base 环境）
- 模型：Qwen3-32B-AWQ（awq_marlin），本地 vLLM 推理
- 数据集：FOLIO validation set，204 samples（`/root/autodl-tmp/crdd` 下）
- 结果目录：`/root/autodl-tmp/crdd/results/`，输出 `mvp_v4_full.json`
- 活跃进程：**PID 29177**（pipeline v4 full run），两个 registry 条目共享此 PID（mvp_pipeline_003b + mvp_pipeline_004）——这是遗留问题，实际只有一个进程
- Cron 监控：mvp_pipeline_003b 和 mvp_pipeline_004 都在 reconcile 中追踪 PID 29177
- 第二台服务器 `westd-32608` 在配置中但本项目未使用

### 3. 📊 当前状态
**刚做完**：D007 决策——撤回 v5 closed-world 方案，改为 v5b（保持 3-way，改进 prompt 减少 lazy Unknown）。

**正在运行**：mvp_pipeline_004（实际 = 003b 恢复运行），v4 pipeline 全量 204 samples。截至创建时已完成 ~41/204，Code Unknown rate 46.3%（偏高，这正是 v5b 要解决的）。

**实验历史摘要**：
| exp_id | 结论 | 关键发现 |
|--------|------|---------|
| mvp_baseline_001 | success | Qwen3-32B direct 74%, 满足 ≤85% 门控 |
| mvp_pipeline_001 | negative | FOL crash 78%, 分歧率仅 4%, 2/5 pass |
| mvp_pipeline_002 | negative | FOL crash 降至 10%, Code crash 40%(thinking泄漏), C1=0% |
| mvp_pipeline_003 | killed | 双进程竞争，数据损坏 |
| mvp_pipeline_004 | RUNNING | v4: truncation检测+thinking-off重试, 全量204样本 |

**等待中**：
- mvp_pipeline_004 cron 回调（进程完成时自动触发）
- Director 对 v5b 方案的进一步指示（Code Unknown rate 高是否需要额外干预）

### 4. 📋 待办（条件触发式）
- mvp_pipeline_004 cron 回调到达 → spawn worker 分析 `results/mvp_v4_full.json`，计算 C1-C5 五维指标，与 v1/v2 对比
- C1(分歧率) ≥ 10% 且 C4(修复优势) ≥ +5pp → **MVP PASS**，立即汇报 Director，进入 Day 4-6 核心 benchmark 阶段
- C1 < 5% 或 C4 ≤ 0 → **MVP FAIL**，触发应急路径：ProofWriter pivot 或 kill，产出 Framing 调整提案
- C1 在 5-10% 灰色区间 → 扩展第二数据集（ProofWriter）再判
- Code Unknown rate > 40%（v4 已观察到 46.3%）→ 需要 v5b prompt 改进（few-shot 引导 Code 路径减少 lazy Unknown），这是 **下一轮迭代** 的核心任务
- registry 里 mvp_pipeline_003b 和 mvp_pipeline_004 共享 PID 29177 → 回调到达时需清理：003b 应标记为 killed/superseded，004 保留为正式结果

### 5. 🎯 战略上下文
- **核心假设**：跨表征（FOL+Python）分歧能诊断形式化错误并指导定向修复，优于盲目重试
- **决策链**：D001(MVP方案) → D002(Reviewer加固criteria) → D005(v1 negative,根因是Z3 crash不是假设错) → D006(v2修复FOL但Code crash) → D007(撤回closed-world,改v5b)
- **项目处于 MVP 验证的最后一搏**：v4 是修复了 FOL truncation + Code thinking 泄漏后的全量运行，如果 C1 分歧率仍 < 5%，核心假设可能真的不成立（不只是工程问题）
- **最容易判断错的事**：之前两次 negative 都是工程 bug（FOL crash 78%, Code thinking 泄漏），不是假设本身的失败。v4 修复了这些 bug 后的结果才是对假设的真正检验——**不要因为之前 negative 就预判 v4 也会 fail**
- **Code Unknown rate 46.3% 是已知风险**：FOLIO ~39% GT=Unknown，加上模型 lazy 倾向，Code 路径 Unknown 偏多会压缩有效分歧样本。但这不影响 v4 结果的有效性（仍可计算有效样本上的 C1-C5），v5b 是后续优化方向
- **双 registry 条目（003b/004）是历史遗留**：因为 003 被 kill 后恢复时创建了两个条目。实际只有一个进程在跑。下一个 session 收到回调时统一清理
