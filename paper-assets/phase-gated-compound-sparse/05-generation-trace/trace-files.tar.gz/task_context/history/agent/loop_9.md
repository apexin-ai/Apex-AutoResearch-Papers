---
loop: 9
reason: idle_timeout
updated: '2026-05-15T00:51:24+00:00'
---

### 1. 🔴 硬约束 / 红线
- GPU 白名单：仅 westd-22162 cuda:0/1/2/3，四块全部在跑 c2_n500 实验，完成前不可抢占
- tex 同步必须用 rsync（`bash artifacts/_project/sync_paper_to_remote.sh`），本地和远程都没有 git remote
- 唯一有效分析脚本：`analyze_n500_unified.py`（B_BOOT=10000）。`analyze_c2_n500.py` 已 DEPRECATED，禁止使用
- Bootstrap B 值全局统一 B=10,000，不可用其他值。Figure 1/5 数据源 `rebootstrap_b10000_results.json` 也是 B=10,000
- d_z 只报 within-importance（不同 sparsity 间）。涉及 imp vs rand 比较的 d_z 不报（D059）
- Qwen s015 n=500 CI 不跨零 → onset threshold 统一为 s≥0.15，删除所有论文中 "marginal at s=0.15" 限定语（Director 已确认）
- Framing 硬约束（D015）：MUST "emergent phase-strategy interaction"；MUST NOT "importance is broken"

### 2. 🖥️ 基础设施快照
- 服务器：westd-22162，工作目录 `/root/autodl-tmp/pacs`
- Python：aml-train 镜像，`/root/miniconda3/bin/python`（conda base，不是 venv）
- 模型路径：DeepSeek-R1-Distill-Qwen-7B + Qwen（具体路径在 `/root/autodl-tmp/pacs` 下，Worker 已知）
- 数据集：`/root/autodl-tmp/pacs/data/MATH-500/`（n=500）
- W&B：无（profiling 实验不走 W&B）
- 活跃进程：
  - c2_n500_deepseek: cuda:0+1, screen c2_n500_gpu0/gpu1, cron ID=c2_n500_deepseek
  - c2_qw_n500_r3: cuda:2+3, screen c2_qw_gpu2/gpu3 (PID 159269+159794), cron ID=c2_qw_n500_r3
- 论文 tex 文件：本地 `artifacts/_project/` + 远程 `/root/autodl-tmp/pacs/paper/`，rsync 同步

### 3. 📊 当前状态
**刚做完**：D058-D062 系列决策执行（median 切换、B=10000 统一、cron 修复、s015 onset 统一）。Worker 池当前为 0（所有准备工作已完成，等实验跑完）。

**RUNNING 实验**：
- `c2_n500_deepseek`（cuda:0+1）：s015✅ s020✅ s025 运行中 (~100-150/500)，s030 待跑。ETA 全部完成 ~2026-05-15 14:00-14:30 UTC+8
- `c2_qw_n500_r3`（cuda:2+3）：s015✅ s020✅ s025 运行中 (~170-190/500)，s030 待跑。ETA 全部完成 ~2026-05-15 12:30-13:00 UTC+8

**等待中**：两个 cron 监控上述实验，完成后自动回调。无 Worker 回调、无 Director 决策待处理。

### 4. 📋 待办（条件触发式）
- c2_qw_n500_r3 cron 回调（~12:30-13:00 UTC+8）→ spawn Worker 跑 `analyze_n500_unified.py`（Qwen 部分），输出 median II + bootstrap CI (B=10000) + d_z within-importance
- c2_n500_deepseek cron 回调（~14:00-14:30 UTC+8）→ spawn Worker 跑 `analyze_n500_unified.py`（DeepSeek 部分），同上
- 两个分析都完成 → spawn Worker 统一更新论文：n=500 tables/figures 替换 + C5b §8 Future Work + C8 限定语（"suggests"/"partial support"）+ Qwen caveat（若仍需）+ 删除 "marginal at s=0.15"
- 论文更新完成 → rsync 同步到远程 → latexmk 编译验证 → 提交 Group C full review
- **截稿 2026-05-25（距今 10 天）**，n=500 更新是最后一批数据变更

### 5. 🎯 战略上下文
**核心结论**：importance-based eviction 的 compound interaction severity 随 sparsity 单调递增（DeepSeek 0.32→9.94, Qwen 0.048→2.619），random 7/8 FAIL。这是 "emergent phase-strategy interaction"。跨模型方向一致（ρ=1.0），跨架构（LLaMA）qualitative consistent 但定量交互弱。

**决策链关键节点**：
- D054: mean→median（random outlier 暴露 mean 不可靠）
- D058→已解决: Qwen n=500 显著（n=50 时不显著是统计功效不足）
- D059: d_z 分场景（imp vs rand 比较不报 d_z）
- D060: C8 partially_confirmed（LLaMA random 也有 phase gradient，与 Qwen/DeepSeek 不同）

**最容易判断错的事**：
1. 不要把 c2_qw_n500（已 failed/被 cron 误杀 5 次）和 c2_qw_n500_r3（当前 RUNNING 的 retry）搞混。r3 是有效的
2. 分析时必须用 `analyze_n500_unified.py` 从 `per_problem_ii` 原始数据重算 CI，不要引用 profiling_results.json 里 B=1000 的预计算值
3. LLaMA 结果不能说 "confirms"，只能说 "suggests"/"provides partial support"——因为 random 也有 phase gradient
4. Qwen mid-phase null rate 高（~45%），论文需要 appendix per-phase effective n 表（Reviewer Warning W5）
