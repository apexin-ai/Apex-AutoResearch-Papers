---
loop: 3
reason: idle_timeout
updated: '2026-05-14T05:13:38+00:00'
---

### 1. 🔴 硬约束 / 红线
- GPU 白名单：westd-22162 cuda:0/1/2/3，不可用其他服务器或 GPU
- 环境激活必须用 `source /root/miniconda3/etc/profile.d/conda.sh && conda activate base`，不存在 .venv
- 代码/数据/模型全在 `/root/autodl-tmp/pacs/`，根分区空间有限不要往别处写大文件
- Qwen 实验之前 3 组 (s015/s020/s030) 被 kill，原因未记录在 registry——重跑前必须搞清楚为什么被 kill，不要盲目重提交
- EMNLP 2026 ARR 截稿 2026-05-25（距今 11 天），所有工作围绕这个 deadline

### 2. 🖥️ 基础设施快照
- 服务器：**westd-22162**，4× RTX 6000 Pro 96GB
- 工作目录：`/root/autodl-tmp/pacs/`
- Python：`/root/miniconda3/bin/python`（conda base 环境）
- Qwen2.5-7B-Instruct 已下载：`/root/autodl-tmp/models/Qwen2.5-7B/`
- 主模型：DeepSeek-R1-Distill-Qwen-7B（路径在 pacs 目录下，具体路径需 SSH 确认）
- W&B：未在 memory.md 中记录 project name，需 SSH 查
- 活跃进程：
  - v6_random_s020: PID 71488, cuda:1
  - v6_random_s015: PID 72073, cuda:0
- cuda:2 和 cuda:3 当前空闲（qwen_importance_s025 在 QUEUED 但未分配 GPU）
- Cron：reconcile_crons 返回 0 条活跃 cron——**v6_random 两个 RUNNING 实验可能没有 cron 监控**，需要确认或重新注册

### 3. 📊 当前状态
- **刚完成**：v6 importance 4 组 (s015/s020/s025/s030) 全部 success，bootstrap CI p=0.0000，gradient 11-42×。Per-problem bootstrap 统计确认完成。
- **正在跑**：v6_random_s015 (cuda:0) + v6_random_s020 (cuda:1)——这两个是 v6 importance 的对照组，完成后可做 problem-level permutation test (importance vs random)
- **排队中**：qwen_importance_s025 (QUEUED, retry_count=1)——cross-model replication 唯一存活的实验，但没有 GPU 分配也没有 cron
- **空闲 GPU**：cuda:2 和 cuda:3 没在跑任何东西——**违反 L1 红线"分配的 GPU 必须每张都在跑"**
- **论文写作**：尚未启动，ROADMAP 标记为下一步
- **Worker 池**：当前 0 个 Worker——**违反 L1 红线"Worker 池 < 2 = 失职"**
- 统计：success 11 / negative 7 / failed 11 / killed 6 / 共 38

### 4. 📋 待办（条件触发式）
- **立即**：确认 v6_random_s015/s020 是否有 cron 监控，没有则注册 cron
- **立即**：cuda:2/3 空闲 → 提交 qwen_importance_s025 (已 QUEUED) + 至少再开一个 qwen 实验 (s015/s020/s030 中选)，填满 GPU
- **v6_random 完成 →** spawn Worker 做 problem-level permutation test (importance vs random per_problem_ii 对比)，更新 registry，汇报 Director
- **Qwen 任一实验完成 →** 检查是否观察到 phase-modulated severity gradient；≥ 5× gradient 则 cross-model claim 成立，< 5× 则需要讨论
- **v6 random + Qwen 数据齐备 →** 启动论文写作 pipeline（读 paper_framing.md，派 Worker 写各 section）
- **距截稿 ≤ 7 天 →** 必须有完整论文草稿进入 review 循环

### 5. 🎯 战略上下文
- **核心发现**：importance-based eviction 的 compound interaction 在 low-sparsity phase 急剧放大（gradient 12-75×），random 保持平坦（~1×）。Compound sparsity severity 是 strategy-dependent 且 phase-modulated 的。
- **Pivot 历史**：原 hypothesis 是 sub-additive (negative II)，v5 全面否定后 pivot 到描述 super-additive gradient 的 phase-modulation 特性 (D014)
- **Crossover 现象**：s=0.25 时 importance 在 high phase 优于 random，但 low phase 劣于 random——这是核心 novelty，文献空白已由 3 个 Worker 独立确认
- **机制解释**：Entropy-discrimination collapse——head pruning 后 surviving heads 注意力更均匀，importance score 区分度崩溃，importance eviction 退化为有偏伪随机
- **最易判断错的事**：
  1. 不要把 v5 (segment-level) 和 v6 (per-problem) 的数据混用对比——v6 才有 per_problem_ii
  2. 不存在 v6 random 实验的历史数据——v5 random 是 segment-level 的，v6 random 正在跑
  3. Qwen 模型路径是 `/root/autodl-tmp/models/Qwen2.5-7B/`（不是 HF cache）
  4. 3 个 Qwen 实验被 kill 的原因不明，不要假设环境问题——可能是 Director 主动 kill 的（需查 registry notes 或问 Director）
- **决策链**：D010 (MVP FAIL, pivot) → D014 (phase-modulated severity 新发现) → D015 (GO) → D017 (bootstrap confirms) → 当前：cross-model + 论文
