---
loop: 4
reason: max_messages
updated: '2026-05-15T10:30:54+00:00'
---

### 1. 🔴 硬约束 / 红线
- GPU 只能用 westd-22162:cuda:0~3（项目配置 `execution.gpu_ids`）
- Qwen 统计量必须用 n=475（low+high 有效即可），**不是** n=274（complete-case）——registry Qwen 数据可能仍是旧值，以 `n500_unified_final.csv` 为唯一数据源
- paper_provenance.yaml C019 已 deprecated，C019b 是当前版本——random masking 在 s025+ 跨模型显著，**不要**写 "random = no phase gradient"
- Bonferroni 主报告用 k=4（family-wise per model×strategy），不是 k=48
- 论文 framing 硬约束（D015）：MUST "emergent phase-strategy interaction"；MUST NOT "importance is broken"；MUST NOT claim importance-only super-additivity without random threshold qualifier (D063)
- 用户已确认 MF3 走方案 A（scope-down to mathematical reasoning），不加新 benchmark

### 2. 🖥️ 基础设施快照
- 服务器：westd-22162 (connect.westd.seetacloud.com)，account=root
- 工作目录：/root/autodl-tmp/pacs
- GPU：RTX 6000 Pro ×4，当前全部空闲
- 本地 artifacts：`projects/phase-gated-compound-sparse/artifacts/n500_analysis/` 下 10 个文件全部就绪（csv/json/md）
- 论文目录：`artifacts/_project/paper/`（main.tex + 分文件，pdflatex 可编译）
- 审稿群（Group C）：review_chat_id = `oc_57b24a804b56707ec9118a483a8ac65e`
- 无活跃 GPU 进程、无 RUNNING 实验、无 cron 任务

### 3. 📊 当前状态
**Paper Agent 正在执行 Phase 2 + Phase 3**：
- Phase 2：n=500 数据填充所有 placeholder + 补充统计写入（CI shrinkage, BH-FDR, JT test, G CI, mpl sensitivity, 新引用 PM-KVQ/RLKV/LongFlow, random threshold story, oracle pilot data）
- Phase 3（排队中）：segmentation sensitivity Appendix 表格（tercile/quartile/quintile spot check）

Paper Agent 完成后需要：
1. Reviewer 审查更新后的论文
2. 提交 Group C 再次审稿（`submit_paper_to_review`，推荐 continue 模式）
3. 如果距截稿 ≥4 天，可考虑跑 asymmetric sparsity spot check（6h GPU，nice-to-have）

Registry：83 实验全部 DONE（38 success / 10 negative / 14 failed / 21 killed）

### 4. 📋 待办
- Paper Agent 回复 Phase 2 完成 → 检查 placeholder 残留 + consistency check → 发 Phase 3（如未自动执行）
- Phase 3 完成 → `submit_paper_to_review(project, paper_path="projects/.../paper/main.tex", venue="EMNLP 2026 ARR", recommended_review_mode="continue")` → 等 Group C 审稿
- 收到 Group C Round 2 审稿报告 → 按 review-report-action skill 处理（Holistic Pass → Action Matrix → post_to_reviewer → 定稿）
- 距截稿 ≥4 天且 Group C 无新 critical → 考虑 asymmetric sparsity spot check（SF5，6h GPU）
- 距截稿 ≤2 天 → 最终 PDF 视觉检查 + 提交准备

### 5. 🎯 战略上下文
- 项目核心：compound sparsity severity 是 strategy × phase 的涌现交互，importance 放大效应 3-39× 大于 random，存在 sparsity threshold ~s020-s025
- D066 Action Matrix：14/17 原有 issue + 3 Reviewer 补充 = 20 条，大部分已 in_progress 或通过 Phase 1/2 修复
- Group C Round 1 评分 2.5/5 (Weak Reject)，目标 3.0+ (Borderline Accept)
- **最容易判断错的事**：(1) 数据源混用——registry 的 Qwen 数据是旧的 n=274，只信 CSV (2) Bonferroni scope——k=48 过严会让 DS random s025/s030 变 NS，必须用 k=4 (3) Random masking 叙事——不是"无 phase gradient"，是 threshold story (4) LLaMA 只有 n=50，不要 overclaim
- **已跳过的实验**：GPQA pilot（风险调整 ROI 负）、LLaMA n=500（高成本低边际）——Reviewer 评估确认 skip
- Spearman ρ=1.0 的 p=0.042 是单尾，双尾 p=0.083 不显著——JT test 已替代（全部 p<1e-9）
