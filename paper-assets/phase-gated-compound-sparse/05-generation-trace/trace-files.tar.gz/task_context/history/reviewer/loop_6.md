---
loop: 6
reason: max_wall_time
updated: '2026-05-14T21:50:48+00:00'
---

### 1. 🔴 硬约束 / 红线
- GPU 白名单：c2_n500_deepseek 用 cuda:0,cuda:1；c2_qw_n500_r3 用 cuda:2,cuda:3。越界立即 CRITICAL。
- 论文数据硬约束：D054（只用 median，禁引 mean）、D059（d_z 仅报 within-importance，imp-vs-rand d_z 不入论文）、D015（framing 必须是 "emergent phase-strategy interaction"，禁说 "importance is broken"）。
- 论文 .tex 文件禁止现在修改——等 n=500 全部 16 conditions 完成后按 `n500_paper_update_checklist.md` 统一替换。
- LLaMA (c3_llama) 数据 n=50 不重跑，但 LLaMA 与 DS/QW 的比率声明会因 n=500 数值变化需重算（4 处）。
- Cron 监控必须适配 screen session PID 切换间隙（c2_qw_n500 已被误判 5 次）。

### 2. 🖥️ 基础设施快照
- 服务器：westd-22162 (root)，4× NVIDIA RTX PRO 6000 Blackwell (98GB each)
- 工作目录：`/root/autodl-tmp/pacs`
- Python：系统 python3（非 venv/conda）
- 数据：`/root/autodl-tmp/pacs/data/math500.json` (n=500) 和 `/root/autodl-tmp/pacs/data/MATH-500/` (Qwen 格式)
- 模型：`/root/autodl-tmp/pacs/checkpoints/DeepSeek-R1-Distill-Qwen-7B` + `Qwen2.5-7B-Instruct`
- 分析脚本：`/root/autodl-tmp/pacs/scripts/analyze_c2_n500.py`（D054-compliant，主分析）
- 活跃进程：
  - GPU 0: PID 156554 (c2_n500_deepseek imp), tmux: c2_n500_gpu0
  - GPU 1: PID 154305 (c2_n500_deepseek rand), tmux: c2_n500_gpu1
  - GPU 2: PID 159269 (c2_qw_n500_r3 imp), screen: c2_qw_gpu2
  - GPU 3: PID 159794 (c2_qw_n500_r3 rand), screen: c2_qw_gpu3

### 3. 📊 当前状态
我刚完成一批 worker 审查（code_reference_fixes / cron_reregister / monitor / n500_analysis_pipeline / paper_update_audit 共 7 个 worker），全部 PASS。

Registry RUNNING：
- **c2_n500_deepseek**: s015 DONE, s020 进行中（imp 51%, rand 60%），ETA 全部 8 conditions ~May 15 16:00 CST
- **c2_qw_n500_r3**: s015 DONE, s020 进行中（imp 49%, rand 45%），ETA ~May 15 15:00 CST

关键已确认结论：n=500 s015 Qwen imp CI [0.049, 0.093] **排除零**，D058 已解决。预注册应走"升级"方案（删 ^ns，叙事改为 "all four sparsity levels"）。

### 4. 📋 待办（条件触发式）
- c2_n500_deepseek 或 c2_qw_n500_r3 cron 回调 → 独立核实 GPU PID 存活 + 进度推进（注意 screen PID 切换间隙导致的 false positive）
- 全部 16 conditions DONE → 核实最终分析：(1) B=10000 bootstrap 重跑 (2) Qwen s015 d_z 升级叙事 (3) random 7/8 vs 8/8 判定 (4) LLaMA 比率重算 (5) 按 n500_paper_update_checklist.md 逐项替换后做 consistency audit
- Director 转发 paper 章节审查 → 按 §5 写作对抗审查模式执行（维度评分模板）
- Director 转发 framing 调整提案 → Read negative-framing-review skill 后四维度审

### 5. 🎯 战略上下文
项目核心发现：compound sparsity severity 是 strategy × phase 的涌现交互。Importance eviction 的 phase gradient 69-274×，random ~1×。三模型两架构验证（DS/QW 同架构 confirmed，LLaMA 跨架构 partially_confirmed）。投稿目标 EMNLP 2026 ARR，DDL 2026-05-25。

**易错点**：
1. Mean 数据绝对不可引入论文（ds_rand mean=-8749，灾难性 outlier，D054 硬约束）
2. n=500 Qwen mid-phase null rate 45.2%——不是 bug，是 Qwen 无显式 think delimiter 导致 phase segmentation 退化，有效 n=274 仍足够但需在论文中声明
3. LLaMA random 也显示显著 phase gradient（d_z 0.35-0.44），与 DS/QW random 7/8 FAIL 模式不同——C8 必须用 "suggests"/"partial support"，禁用 "confirms"
4. paper_framing.md 已更新为 d_z（不是 pooled d），与论文一致
5. 编译日志当前无 undefined reference / warning——之前 3 个 CRITICAL（sec:experiments 引用错误、discussion CI 错误引用、d vs d_z 不一致）已全部修复
