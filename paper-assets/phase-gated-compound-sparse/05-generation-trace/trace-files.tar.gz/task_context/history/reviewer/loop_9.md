---
loop: 9
reason: max_wall_time
updated: '2026-05-15T16:50:40+00:00'
---

### 1. 🔴 硬约束 / 红线
- 本项目 GPU 白名单：cuda:0/1/2/3（westd-22162 四卡 H800）。当前 DS 已完成释放 gpu0/1，QW 占 gpu2/3
- gsm8k_profiling_ds registry 被 Worker 标记为 DONE/success，但我已 post CRITICAL 给 Director 要求降级为 inconclusive——下一个"你"不要把这个实验当 success 引用
- DS importance II_low = 精确 0.0（100/100 non-null entries），与 MATH-500 基线矛盾（MATH-500 ii_low 范围 -5.4 到 1524）。Worker 说"符合预期"是错的，不要采信
- GSM8K 脚本用 mean-based CI + N_BOOTSTRAP=1000，MATH-500 用 median-based + N_BOOTSTRAP=10000——跨数据集对比前必须对齐方法论

### 2. 🖥️ 基础设施快照
- 服务器：westd-22162(root)，代码根 `/root/autodl-tmp/pacs`
- 本地 workspace：`/home/ubuntu/.agent-ml-research-idea_gen_0509_11/projects/phase-gated-compound-sparse/`
- GSM8K 脚本：`/root/autodl-tmp/pacs/run_profiling_gsm8k.py`（非 pacs/profiling/ 下）
- GSM8K 数据：`/root/autodl-tmp/pacs/data/gsm8k_test.json`（1319 problems，seed=42 抽 50）
- DS 输出：`analysis_output/gsm8k/ds_importance/` 和 `ds_random/`（profiling_results.json + generations.json）
- QW 输出目录已创建但空：`analysis_output/gsm8k/qw_importance/` 和 `qw_random/`
- QW 进程：PID 245313 (qw_imp, cuda:2), PID 245314 (qw_rand, cuda:3)
- 日志：`/tmp/gsm8k_qw_imp.log`（50/50 已处理但未写输出——可能还在做 II 计算）、`/tmp/gsm8k_qw_rand.log`（38/50）
- MATH-500 基线 DS profiling：`profiling_output_n500_bf16_ds_imp_s025/profiling_results.json`

### 3. 📊 当前状态
刚完成 gsm8k_profiling_ds 诊断 Worker 的审查，post 了 CRITICAL 给 Director（6 条 finding）。核心问题：DS importance II_low 全零退化 + DS random FAIL + 全部 aggregate perplexity = NaN + Worker 过早标 success。

**Registry 活跃实验**：
- gsm8k_profiling_ds: DONE/success（我要求降级为 inconclusive，等 Director 决策）
- gsm8k_profiling_qw: RUNNING（QW imp 50/50 处理完但输出目录空，QW rand 38/50）
- SF5 asymmetric: PREPARING（注意启动后核实 GPU 分配，L1 红线 #4）

**等待中**：
- QW 两个条件完成 → 需立即审查，重点看 QW importance 是否也出现 II_low = 0 退化（如果 QW 也全零 → 系统性代码 bug；QW 非零 → DS 模型特异性问题）
- Director 对 gsm8k_profiling_ds registry 降级的决策
- Paper Agent Round 8 文本修改可能提交审查

### 4. 📋 待办
- QW importance 完成 → 立即检查 ii_low 分布：全零则 post CRITICAL（系统性 bug），非零则 post WARNING（DS 特异性）
- QW random 完成 → 检查 verdict（PASS/FAIL）+ ii_low 分布，与 DS random 对比
- QW 全部完成 → 汇总 GSM8K 四条件审查报告
- Director 回复 gsm8k_profiling_ds 降级决策 → 跟进 registry 状态
- SF5 asymmetric 启动 → ssh_read_only 核实 CUDA_VISIBLE_DEVICES 在 gpu_ids 白名单内
- Paper Agent 提交章节审查 → 按 §5 模板评分，特别注意 GSM8K 相关 claim 不能基于退化数据

### 5. 🎯 战略上下文
- EMNLP 2026 ARR deadline 2026-05-25（10 天）
- 核心 claim: compound sparsity 的 severity 是 phase-modulated 的（importance >> random，单调递增 with sparsity）——MATH-500 n=500 数据强力支撑（DS p<1e-70, QW p<1e-15）
- GSM8K 是 cross-dataset validation（Appendix），不是主实验。即使 GSM8K 失败，主 claim 仍成立，但需要诚实报告 GSM8K 结果
- **最易判断错的事**：Worker 和 Agent 倾向把退化数据包装为"符合预期"（rationalization）。II_low = 0 不是"importance masking 在 low phase 无效果所以合理"——MATH-500 同模型同方法有丰富非零 II_low，GSM8K 全零是异常
- **最易踩的坑**：GSM8K 脚本的 aggregate perplexity 全 NaN 是独立 bug，不影响 per-problem II 计算（II 从 per-segment PPL ratio 得出），但如果不修复会让后续分析 Worker 误判数据损坏
- Appendix B multiplicative null 数据已确认来自 n=50 旧数据，需更新为 G_× ≈ 51-183×（已 post 给 Director）
- background.tex L21 和 appendix.tex L38 的 "disjoint dimensions" 措辞与 §6 causal coupling 矛盾，已 flagged
