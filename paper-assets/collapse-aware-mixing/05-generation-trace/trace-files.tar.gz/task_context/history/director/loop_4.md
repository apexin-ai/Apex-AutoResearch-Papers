---
loop: 4
reason: max_messages
updated: '2026-05-13T23:37:31+00:00'
---

### 1. 🔴 硬约束 / 红线
- GPU 只用 cqa1-38874 的 cuda:0（项目唯一分配）
- AutoDL tmux 命令**必须**包含：`source /etc/network_turbo; export HF_HOME=/root/autodl-tmp/.hf_cache; export REQUESTS_CA_BUNDLE=/etc/ssl/certs/ca-certificates.crt; export SSL_CERT_FILE=/etc/ssl/certs/ca-certificates.crt; export HF_HUB_DISABLE_XET=1`。已因缺少此前缀导致 3 次 GPU 空转事故
- compare_eff_rank_vs_ngram.py 的 verdict **不可直接引用**——检测阈值不对称 20 倍（generated eff_rank 0.5% vs n-gram 10%），需统一阈值后重新判定
- 根分区 ~30GB，所有大文件写 `/root/autodl-tmp/`

### 2. 🖥️ 基础设施快照
- 服务器：cqa1-38874 (connect.cqa1.seetacloud.com)，工作目录 `/root/collapse-aware-mixing/`
- Python：`/root/miniconda3/bin/python3`（conda base env，`source /root/miniconda3/etc/profile.d/conda.sh && conda activate base`）
- 模型：EleutherAI/pythia-1b，checkpoint 在 `/root/autodl-tmp/output_v7/G{0,1,2}/training/`（每代 6 个 checkpoint：76/152/228/304/305/final_model，共 18 个）
- 数据集：wikitext-103-raw-v1，HF cache 在 `/root/autodl-tmp/.hf_cache/`
- 活跃进程：pivot_b_full_18ckpt（PID 109597，tmux=pivot_b_full_18ckpt，**状态不确定**——刚派 Agent 去检查是否存活）。已向 Agent 发 urgent message 确认状态
- Pivot B final-only 结果在 `/root/autodl-tmp/output_v7/pivot_b_analysis/`
- 全 checkpoint 输出目标：`/root/autodl-tmp/output_v7/pivot_b_analysis_full/`

### 3. 📊 当前状态
**关键：pivot_b_full_18ckpt 状态未知。** 已运行 ~5h，GPU 监控显示 0% 利用率——可能已完成或已死。刚派 Agent 去确认 PID 存活和进度。

**已完成的里程碑：**
- v7 G0/G1/G2 训练+评估全部完成（G2 eval 因 KL bug crash 后修复重跑成功）
- C1 原假设 definitively falsified（D014）：holdout eff_rank 676→683 上升，generation 完全崩塌
- Pivot B final-only 验证：generated eff_rank 63.89→3.87→1.06 (-98.3%)，信号极强（D016 GO）
- Direction C killed：所有层 holdout eff_rank 变化 <1%
- Baseline dry-run 6/6 通过，脚本就绪

**Registry RUNNING：** pivot_b_full_18ckpt（可能已完成/死亡）
**等待中：** Agent 确认 pivot_b_full_18ckpt 状态的回调

### 4. 📋 待办
- Agent 回报 pivot_b_full_18ckpt 存活 → 等完成（预计已接近尾声或已完成）
- Agent 回报 pivot_b_full_18ckpt 死亡 → 检查已有输出，如需重跑则用 `--num-samples 200 --max-length 2048`（不加 --only-final）重新提交
- 全 checkpoint 结果到手 → **用统一阈值（rel=5% 或 2σ noise floor）重跑 compare_eff_rank_vs_ngram.py** → D013 最终判定：
  - generated eff_rank 比 n-gram 更早/更平滑 → **Pivot B GO**，paper story = "Where You Look Matters"
  - generated eff_rank 不比 n-gram 好 → **D015 保底路径 Q2**：negative result paper（holdout fails）+ n-gram PI controller 作为实用贡献
  - marginal case → 跑端到端 PI 对比（generated eff_rank vs n-gram 作为 PI 信号的最终 PPL 差异）
- D013 判定完成 → 立即启动 6 个 baseline（w=0/0.1/0.3/0.5/0.7/1.0），脚本已 dry-run 通过
- baseline 启动后 → 改 controlled_pipeline.py 控制信号（holdout eff_rank → generation-side metric），准备 PI sweep

### 5. 🎯 战略上下文
**决策链：** D008(GO/NO-GO 标准) → D011(v7 G1 eff_rank 挑战 C1) → D012(Pivot B>C>A) → D013(generated eff_rank 须比 n-gram 有额外价值) → D014(C1 killed by G2) → D015(失败预案: Q2 negative result 首选) → D016(Pivot B 信号确认 GO, Direction C killed)

**核心发现（已确认）：** holdout eff_rank 在 total collapse 下反而**上升**（+0.96%），generated eff_rank 暴跌 -98.3%。所有 holdout metrics（eff_rank/PPL/token_entropy/spectral_entropy）对 early collapse 完全失灵。

**最容易判断错的事：**
1. compare_eff_rank_vs_ngram.py 的 verdict 看起来给了答案但**方法论有两个缺陷**：(a) 之前用 3 final_model vs 18 checkpoint 对比不公平；(b) 检测阈值不对称 20 倍。拿到全 checkpoint 数据后必须用统一阈值重新判定
2. Agent 多次因缺少 AutoDL 环境前缀导致 GPU 空转（3 次事故），每次提交 GPU 任务必须检查命令是否包含 network_turbo + HF_HOME + SSL certs
3. paper_framing.md 和 ROADMAP.md 部分内容过时（顶部仍写 "MVP v7 尚未完成"），需要更新
4. Reviewer 指出 Plan A（n-gram + PI）不够 EMNLP main，只够 Findings/workshop。如果 Pivot B 也不行，走 Q2 negative result paper 是最有价值的保底
5. DDL 2026-05-25（~11 天），GPU 每小时空转都在压缩实验窗口
