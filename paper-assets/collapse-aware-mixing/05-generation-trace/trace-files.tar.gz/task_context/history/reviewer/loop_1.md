---
loop: 1
reason: max_wall_time
updated: '2026-05-12T14:56:26+00:00'
---

### 1. 🔴 硬约束 / 红线
- 本项目只能用 **cuda:0**（服务器 cqa1-38874 只有 1 张 RTX PRO 6000 96GB）
- `env_init.sh` 必须 source 而非直接执行（需导出环境变量到当前 shell）；`preflight.sh` 必须用 `bash` 执行而非 `source`（脚本末尾有 `exit`，source 会杀死调用方 shell）——这个 bug 导致了第 5 次失败
- 必须设 `TRANSFORMERS_OFFLINE=1`（或所有 `from_pretrained` 加 `local_files_only=True`），AutoDL 网络对 HuggingFace 不可达
- wikitext-103 pack 后只有 **57,052 sequences**，`tokens_per_generation` 不能超过 ~90M（否则 train + holdout 越界）

### 2. 🖥️ 基础设施快照
- 服务器：**cqa1-38874**，工作目录 `/root/collapse-aware-mixing`
- Python：`/root/miniconda3/bin/python3`（conda base 环境，不是 venv）
- 激活方式：`source /root/miniconda3/etc/profile.d/conda.sh && conda activate base`
- 模型缓存：`/root/autodl-tmp/.hf_cache/hub/models--EleutherAI--pythia-1b/`（已完整缓存）
- 数据缓存：`/root/autodl-tmp/.hf_cache/datasets/wikitext/wikitext-103-raw-v1/`（已缓存）
- tokenized 数据缓存：`/root/autodl-tmp/output/real_data_cache/`（57,052 packed seqs）
- 训练输出：`/root/autodl-tmp/output/G0/training/`
- 日志：`/tmp/pilot_v4.log`（当前运行的主日志）
- 活跃进程：G0 训练中（GPU 100%, 22.8GB），PID 未注册到 registry

### 3. 📊 当前状态
**训练终于在跑了。** 经历 v1-v4 共 7 次失败后（conda/network/zombie/source+exit/500M参数/IndexError/SIGHUP），当前运行参数正确：
- 90M tokens/gen, 3 代 (G0 real + G1/G2 synthetic), 1,373 steps/gen, checkpoint 每 152 steps
- G0 训练约 step 50/1,373（22:52 启动，~2.09s/step，预估 G0 完成约 23:40 本地时间）
- **Registry 问题**：mvp_pilot_v4 状态为 QUEUED (retry_count=1)，但当前运行的 spec（90M tokens, PID）未更新到 registry。Agent 应补注册。

### 4. 📋 待办
- G0 训练完成（~40 min 后）→ 检查第一批 spectral rank + PPL 指标是否正常输出，loss 曲线是否收敛
- G0 eval checkpoint 出结果 → 记录 G0 baseline（spectral_rank_mean, spectral_rank_std, ppl_final），这些是 GO/NO-GO 判定的 σ 基准
- G1 训练开始 → 确认 model chaining 正确（prev_model_dir 指向 G0 final checkpoint，而非重新加载 pretrained）
- G1/G2 eval 完成 → 按 NO-GO 决策树判定：spectral rank 下降 ≥1σ 且 PPL 未上升 ≥2pts/5% → GO；否则按 5 条路径分别处理
- 训练意外中断 → 检查 `/tmp/pilot_v4.log` 末尾、`nvidia-smi`、进程状态，定位是 OOM/SIGHUP/代码 bug

### 5. 🎯 战略上下文
- **核心假设**：spectral effective rank（embedding Gram 矩阵）在 iterative synthetic training 的 collapse 过程中比 PPL 更早下降（leading indicator）
- **决策链**：D001（MVP 方案）→ D002（量化 GO/NO-GO 标准）→ D003（OpenWebText→wikitext-103, 500M→100M→90M）
- **DDL**：EMNLP 2026 ARR 2026-05-25，剩 13 天
- **易错点**：
  1. 不要用"人类时间直觉"判断进度——AI+GPU 的迭代速度远快于人类，只看 GPU-hours 是否够
  2. config.py 注释与实际值不一致（注释写 500M，值是 100M）——以代码值为准
  3. main_experiment.py（全量实验用）仍有 3 个未修复 bug：PI controller optimizer state reset (CRITICAL)、PI 条件缺 KL 计算、fixed_mix 默认比例 0.5 非黄金比例 0.618——但 MVP 阶段不用这个文件
  4. pilot_pipeline.py 的 `from_pretrained` 调用没有 `local_files_only=True`，依赖 env_init.sh 设置 `HF_DATASETS_OFFLINE=1`，但这只管 datasets 库不管 transformers——如果网络恢复没问题，网络断了会在每次 `from_pretrained` 处卡几分钟重试
