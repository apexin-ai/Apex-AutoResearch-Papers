---
loop: 6
reason: max_messages
updated: '2026-05-13T21:56:38+00:00'
---

### 1. 🔴 硬约束 / 红线
- **transformers 版本必须一致**：repo-level 实验必须全部在 transformers 4.57.6 下训练和 eval。westd 裸 `python3` 用的是 5.8.0（system python3.10），**必须用 conda**（`source /root/miniconda3/etc/profile.d/conda.sh && conda activate base && python3 ...`）或在 home 上跑
- **kill_job 不会杀子进程**：tmux SIGTERM 不传播到实际 Python 训练进程。杀训练必须同时 `kill` 实际 Python PID（通过 `nvidia-smi` 或 `pgrep -P` 确认）
- **CWM v11 checkpoint 是混合版本产物**（D055）：前 500 步 4.57.6 + 后 100 步 5.8.0，不可用于论文数字，仅参考
- GPU 白名单：home cuda:0 / westd cuda:0-3（共 5 张）

### 2. 🖥️ 基础设施快照
- **home-1x5090**：`implicit5638.xyfu.me`，用户 `sonny`，项目目录 `/home/sonny/exec-sim-repair-verifier`
  - system python3.10: transformers **4.57.6** ✅
  - 模型缓存：`/home/sonny/.cache/huggingface/hub/`（Qwen3-4B, Qwen3-8B）
- **westd-48478**：`connect.westd.seetacloud.com`，用户 `sonny`（非 root），项目目录 `/home/sonny/exec-sim-repair-verifier`
  - system python3.10: transformers **5.8.0** ❌ 不要用
  - conda python3.12: transformers **4.57.6** ✅ 必须用这个
  - 模型缓存：`/root/.cache/huggingface/hub/Qwen/Qwen3-4B`
  - checkpoint 目录：`/root/autodl-tmp/checkpoints_repo_*/`
- **eval 脚本**：`eval_repo_cls.py` / `eval_repo_cwm.py` / `paired_bootstrap_repo.py` / `train_repo_cwm.py` / `train_repo_verifier.py`，两台服务器 md5 已同步
- **活跃进程**（Agent 最后汇报时正在修复中，需重新确认）：
  - westd cuda:2: CWM v11 full eval PID 180344（参考数据）
  - westd cuda:1: CWM v12 conda 训练 PID 181202（待确认是否成功启动）
  - home cuda:0: CLS seed123 重启中（原 PID 2998850 OOM 崩溃，Agent 正在 kill 残留进程后重启）

### 3. 📊 当前状态
D054 执行中途 Agent 达到硬限被 reset。Agent 完成了 kill 操作（westd cuda:0/1/3 上的无效进程），发现两个问题：
1. kill_job 只杀 tmux wrapper 不杀子进程 → Agent 用 `kill` 直接杀了 Python PID
2. home CLS seed123 (PID 2998850) step 0 OOM → 可能是 CLS v5 残留进程占显存

**关键未确认项**（Agent reset 前未回复）：
- westd cuda:0/1/3 是否确认释放
- CWM v12 conda (PID 181202) 是否成功启动 + transformers 版本确认
- home cuda:0 残留进程是否已清理 + CLS seed123 是否已重启

registry 中 RUNNING：repo-level-cls-seed123-home / repo-level-cwm-seed123 / repo-level-cls-8b（后两个应已被 kill，registry 可能未更新）

### 4. 📋 待办（条件触发式）
- **新 Agent session 启动后** → 立即让 Agent 汇报所有 GPU 状态（`nvidia-smi` 全量），确认 D054 执行完整性
- **CWM v12 conda 未启动** → 重新发 conda 启动命令（westd cuda:1，命令见 D054 指令）
- **home CLS seed123 未重启** → kill 残留进程 + 重启（加 `PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True`）
- **CLS seed123-home 训练完成** → eval → 与 CLS v5 对比 multi-seed robustness
- **CWM v12 conda 训练完成** → eval（同样用 conda） → 与 CLS v5 做 paired bootstrap + TOST → 这是论文最终 repo-level 数字
- **CWM v11 full eval 完成** → 结果仅做参考（D055 标记不可用于论文），不需要更新 paper

### 5. 🎯 战略上下文
- **核心 claim C1 已初步成立**：CLS vs CWM 差距从 function-level 1.24pp 放大到 repo-level 10.3pp（D052 STRONG GO）。但这个 10.3pp 被 transformers 版本差异污染（D054/D055），需要 clean 环境重跑确认
- **论文 ARR May 25 / EMNLP 2026**：paper patch 已完成 3 轮 Reviewer 迭代（Overall 6/10），等 clean repo-level 数据更新最终数字
- **Function-level 结果安全**：所有 function-level 实验一致使用 4.57.6，论文结论可信
- **最容易判断错的事**：不要用 westd 裸 `python3` 跑任何 repo-level 实验（会用 5.8.0）；不要认为 CWM v11 结果可用（混合 checkpoint）
- **决策链**：D052 (STRONG GO) → D053 (CLS seed123 环境修复) → D054 (全面环境一致性修复) → D055 (CWM v11 降级为参考)
