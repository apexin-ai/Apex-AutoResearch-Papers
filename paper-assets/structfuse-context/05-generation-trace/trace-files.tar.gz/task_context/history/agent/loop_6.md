---
loop: 6
reason: idle_timeout
updated: '2026-05-14T18:04:10+00:00'
---

### 1. 🔴 硬约束 / 红线
- GPU 白名单 **仅 bjb1-42106:cuda:0 和 cuda:1**（曾两次越界 cuda:0/cuda:4 被 CRITICAL）
- m2_full_qwen 的 registry 状态是 ANALYZING（cron 因 s42 进程退出自动设置），但**实验实际仍在运行**（random_s44 在跑），不可覆盖状态或以为实验结束
- m2_full_starcoder 的 `conclusion=failed` 是 timeout kill（random_s42 完成 99%，数据有效），8/9 runs 未跑。已有 Worker `worker_fix_gpu_resume_with_bm25_20260514T175853` 正在处理 resume
- ARR deadline **2026-05-25**，所有实验规划锚定此日期
- Dream 审稿 median=WR（不可修复），D034 已 override gate 继续推进，**禁止 fallback 思维**

### 2. 🖥️ 基础设施快照
- **服务器**: bjb1-42106, 2× RTX PRO 6000 96GB
- **工作目录**: `/root/structfuse`
- **Python**: `/root/miniconda3/bin/python`（conda base 环境，**不是 venv**）
- **激活命令**: `source /root/miniconda3/etc/profile.d/conda.sh && conda activate base`
- **模型**: Qwen/Qwen2.5-Coder-3B, bigcode/starcoder2-3b（HF cache 在服务器默认位置）
- **数据**: `/root/autodl-tmp/structfuse/full_m2_training_data/`（train/val jsonl per strategy per seed）
- **M1 提取输出**: `/root/autodl-tmp/structfuse/full_m1_data/all.jsonl`（6.6GB, 15897 instances, v2 追加中）
- **BM25 数据**: `/root/autodl-tmp/structfuse/full_m2_training_data/{train,val}_bm25_s{42,43,44}.jsonl`
- **活跃进程**:
  - m2_full_qwen: tmux=m2_full_qwen, cuda:0, random_s44 running
  - m1_reextract_v2: tmux=m1_reextract_v2, CPU, ~71/82 groups
- **Cron**: m1_reextract_v2 active（reconcile 确认 still running）
- **Worker**: `worker_fix_gpu_resume_with_bm25_20260514T175853` running（修 StarCoder resume + 可能涉及 BM25）

### 3. 📊 当前状态
**刚做完**: 处理 m2_full_starcoder timeout 失败回调、m2_full_qwen s42 完成回调、plan_018 Phase 1 BM25 数据生成、neg_difficulty_analysis 可视化、re-dream 分析（D034 override gate）。

**Registry 活跃实验**:
| exp_id | 状态 | 摘要 |
|--------|------|------|
| m2_full_qwen | ANALYZING（实际 RUNNING） | random_s42 ✅ R@1=0.5527, s43 ✅ R@1=0.5554, s44 running。后续 embedding×3 + dataflow×3 待跑 |
| m2_full_starcoder | DONE(failed) | timeout kill, random_s42 有效（R@1=0.4604），8/9 runs 未跑，Worker 正在 resume |
| m1_reextract_v2 | RUNNING | ~71/82 groups, CPU, 预计还需几小时 |
| plan_018_bm25 | QUEUED | Phase 1 ✅ 数据就绪, Phase 2 等 GPU |
| plan_015_dynamic | QUEUED | 缩减版 1 seed, 等 GPU |

**等待中**:
- Worker `worker_fix_gpu_resume_with_bm25` 完成 → 处理 StarCoder resume 结果
- m2_full_qwen cron 回调 → 每个 run 完成时
- m1_reextract_v2 cron 回调 → 全部完成时

### 4. 📋 待办（条件触发式）
- `worker_fix_gpu_resume_with_bm25` 完成 → 读产出，确认 StarCoder resume 方案，可能需要重新 submit_training_job
- m2_full_qwen random_s44 完成 → 自动启动 embedding_s42（脚本内顺序执行），持续监控
- m2_full_qwen 9 runs 全部完成 → 统计检验（paired t-test embedding vs random），更新 registry metrics，汇报 Director go/no-go
- m2_full_starcoder resume 完成 → 对比 Qwen 结果，确认 encoder-agnostic claim（pilot negative: dataflow encoder-dependent）
- M2 全部完成 → cuda:0 跑 plan_003 SWE-bench, cuda:1 跑 plan_018 Phase 2 BM25 训练（并行）
- plan_018 Phase 2 结果 → BM25 R@1 vs embedding R@1 决定叙事方向（harm→correction / neutral→systematic）
- m1_reextract_v2 完成 → 合并数据，更新训练数据 count，决定是否需要用扩展数据重训

### 5. 🎯 战略上下文
- **核心结论**: Embedding-distance mining consistently beats random +1.6-2.0pp R@1（Qwen pilot confirmed, StarCoder pilot confirmed for embedding）。Dataflow 位置 encoder-dependent（Qwen: dataflow > random, StarCoder: dataflow < random）
- **决策链**: D018(go/no-go plan) → D022(reextract) → D026(reduce epochs) → D027(early stopping) → D028(Claim 2 降级待 M2) → D029/D030(Dream actions) → D031-D033(BM25 overlap) → D034(override gate, Phase 2 approved)
- **易踩的坑**:
  - m2_full_qwen registry 显示 ANALYZING 但实际还在跑，不要以为结束了
  - StarCoder random_s42 虽然 timeout(EXIT_CODE=124) 但 4200/4242 steps 完成，数据有效，不要重跑
  - run_m2_full_starcoder_resume.sh 需要设足够大的 timeout（≥144h），上次 48h 不够
  - BM25 top-7 Jaccard vs k=50 overlap 差异巨大（87% vs 30%），不要用 87% 预测训练结果
  - val_loss 和 R@1 checkpoint criterion 可能 diverge（s43 已观察到），论文需报告 both
  - 关键路径: M2(~May 19-20) → post-M2 实验(~May 22) → 写作(May 23-24) → ARR May 25, 时间极紧
