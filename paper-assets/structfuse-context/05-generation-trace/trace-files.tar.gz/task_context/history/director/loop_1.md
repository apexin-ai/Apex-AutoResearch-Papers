---
loop: 1
reason: max_messages
updated: '2026-05-12T16:14:58+00:00'
---

### 1. 🔴 硬约束 / 红线
- **GPU 只能用 cuda:4**（cqa1-21977）。之前 PID 59170 跑到 cuda:5 被 Reviewer CRITICAL 打回三次。所有脚本已硬编码 `os.environ["CUDA_VISIBLE_DEVICES"] = "4"`
- **大文件只写 `/root/autodl-tmp/`**，根分区 30GB 已因 checkpoint 爆满崩过一次（P2b run 1 step 200 torch.save 失败）
- **对目录 rm/mv 前必须 `ls -la` 确认是否 symlink**——`/root/structfuse` 是指向 `/root/autodl-tmp/structfuse` 的 symlink，model migration worker 误删模型文件教训
- **P2b 最终结果只看 eval_p2b.py（完整候选池）**，训练时 recall@5/10 = recall@1（pool=4 退化指标），不能用于 pass/fail 判断
- **eval_p2b.py 需评估 best checkpoint（val_loss 最低）和 final checkpoint**，embedding_distance_s42 过拟合严重（best 0.945 vs final 0.874）

### 2. 🖥️ 基础设施快照
- **服务器**: cqa1-21977, `ssh -p 21977 root@connect.cqa1.seetacloud.com`, 密码存于 secret `ssh_password_cqa1_21977`
- **工作目录**: `/root/structfuse/` (symlink → `/root/autodl-tmp/structfuse/`)
- **模型**: `/root/structfuse/models/Qwen/Qwen2.5-Coder-3B/` (5.75GB, 两个 safetensors shard)
- **Checkpoints**: `/root/autodl-tmp/structfuse/checkpoints/p2b_*/`
- **数据**: 训练/验证 jsonl 在 `/root/structfuse/` 下，全量 metadata 59K instances 已预处理
- **CodeQL**: `/opt/codeql/codeql`（需加入 PATH）
- **活跃进程**: P2b 训练中（PID 需确认，可能已换），tmux session `mvp_p2b_contrastive_training`
- **Cron**: 每 5 分钟监控 P2b 训练
- **W&B**: 未配置，P2b 用 WANDB_MODE=disabled

### 3. 📊 当前状态
**MVP P2b（kill/go gate）正在训练**。9 runs = 3 strategies × 3 seeds：
- random × 3 seeds: **全部完成** ✅（recall@1: 0.984/0.984/0.992）
- embedding_distance × 3 seeds: **s42 完成**（过拟合，best recall@1=0.945, final=0.874），**s123 在跑**，s456 待启动
- dataflow_aware × 3 seeds: **待启动**

之前经历：策略名不匹配（`embedding` vs `embedding_distance`）导致 6/9 runs 全部 argparse 失败，已修复重跑。

**Registry**: `mvp_p2b_contrastive_training` 状态可能仍卡在 DONE/failed（多次提醒 Agent 更新未果），实际在跑。

**batch_extract.py**: 3 个 bug 已修复（ClassDef 支持 + min_reachable_files=1 + CodeQL class 谓词），跨 repo 验证通过，dataflow 空率 <5%。M1 全量提取代码就绪但未启动（等 MVP 通过）。

### 4. 📋 待办
- **P2b 9 runs 全部完成 → 跑 `run_eval_all.sh`**（对 9 个 checkpoint 用 eval_p2b.py 评估完整候选池 recall@5），评估 best + final checkpoint
- **eval 结果出来 → 判断 MVP pass/fail**：≥2/3 seed dataflow_aware recall@5 > random ≥2pp → PASS → `complete_mvp()` → 进入 post-mvp-kickoff skill
- **MVP PASS → 立即启动 M1 全量提取**（先修 run_m1_extraction.sh：加 CodeQL PATH、加 DB 自动清理、workers=8），预估 ~53h
- **MVP FAIL（dataflow 无显著优势）→ 排查过拟合**：降 lr / 加 weight_decay / 增大 num_negatives / early stopping，限 1 次重试后仍 fail → kill 项目
- **M1 启动前必须修** run_m1_extraction.sh 的 3 个问题（CodeQL PATH、磁盘清理、workers 数）

### 5. 🎯 战略上下文
- **项目**: StructFuse，用 inter-procedural data-flow hard negatives 训练代码检索器，投 EMNLP 2026 ARR（DDL May 25，距今 13 天）
- **决策链**: D001(MVP 设计) → D002(Reviewer 加固: proxy + multi-seed + kill criteria) → D003(H2 sanity check 并入 P1) → D004(P1 PASS: timeout 0%, Fisher p=6.5e-9, 8/8 recall) → D005(GPU 越界 CRITICAL)
- **核心风险**: 过拟合。505 条训练数据 + 3B 模型 = train loss step 200 归零。embedding_distance 策略过拟合最严重（final 比 best 差 7pp）。如果 eval_p2b.py 三策略差距 <2pp，过拟合导致策略趋同是最可能解释
- **易错点**: (1) 不要引用训练时 recall@5/10 作为证据，那是退化指标（pool=4）(2) registry 状态经常与实际不一致，查状态必须 SSH 验证 PID + nvidia-smi (3) `run_p2b_all.sh` 和 `run_eval_all.sh` 的策略名列表必须同步 (4) Human Review Note 中有 4 条论文 framing 优化建议（改标题、双支柱动机、跨域泛化、形式化定义），post-MVP 写 paper_framing.md 时要参考
