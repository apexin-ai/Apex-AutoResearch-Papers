---
loop: 4
reason: max_messages
updated: '2026-05-14T07:58:33+00:00'
---

### 1. 🔴 硬约束 / 红线
- 本项目只能用 cuda:0 和 cuda:1（bjb1-42106，2× RTX PRO 6000 96GB）
- D026: 当前 s42 runs 保持 3 epochs 跑完，后续 s43+ 必须用 2 epochs（脚本已改）
- D024: 旧 Claim 2（"embedding harms"）已证伪，paper_framing.md 已重写。**绝对不能**在任何写作中引用旧的 -27pp BM25-proxy 数据作为 embedding 危害证据
- m1_reextract_v2 数据定位为 camera-ready，不用于当前 M2 训练（没时间重跑）
- plan_014 缩减为 6 runs（D025）：2 strategies × 3τ × 2 epochs，不是原来的 9 runs

### 2. 🖥️ 基础设施快照
- 服务器：bjb1-42106 (connect.bjb1.seetacloud.com)，工作目录 `/root/structfuse-context/`（代码）+ `/root/autodl-tmp/structfuse/`（数据/模型/checkpoint）
- Python：系统 Python 或项目 venv（需 Agent 确认）
- 模型缓存：`/root/autodl-tmp/structfuse/models/Qwen/Qwen2.5-Coder-3B`
- 训练数据：`/root/autodl-tmp/structfuse/full_m2_training_data/`（9 个 train/val jsonl）
- Dataflow graph：`/root/autodl-tmp/structfuse/dataflow_graph.json`（94MB）
- Checkpoint 输出：`/root/autodl-tmp/structfuse/checkpoints/m2_full/`
- Eval 输出：`/root/autodl-tmp/structfuse/eval_results/`
- Artifacts：`/root/autodl-tmp/structfuse/artifacts/`（neg_difficulty 图表等）
- 活跃进程：PID 73558 (m2_full_qwen s42, cuda:0), PID 76627 (m2_full_starcoder s42, cuda:1)
- m1_reextract_v2：4 workers 后台跑 CodeQL 提取，~13% 进度

### 3. 📊 当前状态
**刚做完**：D024 paper framing 重写 + D025 plan_014 缩减 + D026 epoch 缩减（eval@2000 确认过拟合）+ neg_difficulty 可视化 Figure + plan_003 eval pipeline dry-run v2 PASS + plan_014 脚本更新 PASS + experiment_plan.yaml 更新

**RUNNING 实验**：
- m2_full_qwen: Qwen random_s42, step ~3500/4242 (epoch 3), best R@1=55.3% @step1000, 预计 ~18:30 CST 完成 → s43 自动启动 (2 epochs)
- m2_full_starcoder: StarCoder random_s42, step ~2400/4242 (epoch 2), best R@1=45.4% @step1000, 过拟合 @1500 确认, 预计 ~01:30 明天完成
- m1_reextract_v2: 后台 CodeQL 提取

**等待中**：
- Dream `dream_20260514T075732`（full review mode，基于 D024 新 framing）正在运行，15-25 min 完成后会注入 session
- 用户在等 Dream 结果

### 4. 📋 待办
- Dream `dream_20260514T075732` 完成回调 → Read `dream-report-action` skill → 分析三档审稿 → 汇报用户
- Qwen s42 完成（~18:30 CST）→ 确认 s43 自动启动成功 → 检查 s43 用的是 2 epochs
- StarCoder s42 完成（~01:30 明天）→ 同上确认 s43
- 全部 18 runs 完成（~May 17-18）→ 统计检验（bootstrap CI, paired t-test）→ go/no-go 判定
- M2 完成后 → plan_014 temp ablation 双卡并行（~35h wall time）→ plan_003 SWE-bench eval
- 写作时：plan_015 → Limitation 段落（static vs dynamic mining confound），plan_017 → Discussion 段落（inference-time graph comparison，0 GPU-h）

### 5. 🎯 战略上下文
- **核心决策链**：D017(pilot 结果验证) → D024(framing 重写：从"method beats all"转为"systematic analysis") → D025(plan_014 缩减 6 runs) → D026(epoch 3→2, 节省 48h/GPU)
- **新 framing 三条 claim**：(1) embedding mining 普遍有效（纠正 CoCoHaNeRe 误解）(2) dataflow mining 有条件有效（表征饱和度机制）(3) CodeQL 可扩展
- **关键路径**：M2(May 18) → plan_014(May 19) → plan_003 SWE-bench(May 21) → 统计+初稿(May 24) → ARR May 25
- **易错点**：(1) 不要把 MVP 的 BM25-proxy 结果 (-27pp) 当作 embedding distance 证据，那是 mislabeling (2) n=3 seeds 统计功效很低(df=2)，Type II error 高，No-Go 不等于无效应 (3) 过拟合模式一致（两编码器都 step 1000 best），但 StarCoder 的 eval@1500 降幅比 Qwen 小（-0.5pp vs -3pp），表征空间更健康 (4) plan_014 的 temperature 是 learnable parameter（`log_temperature`），ablation 测的是初始化值，已修复传参 bug
