---
loop: 13
reason: max_wall_time
updated: '2026-05-16T00:16:42+00:00'
---

### 1. 🔴 硬约束 / 红线
- GPU 分配：cuda:0 (Qwen 训练链 + Director 批准的单个 SWE-bench retrieval eval 可并行) + cuda:1 (StarCoder 训练链)。跨项目进程禁止，同项目需 Director 批准
- m1_reextract_v2 是纯 CPU 任务（4 workers），不要 kill
- `all.jsonl`（/root/autodl-tmp/structfuse/full_m1_data/all.jsonl）是 May 13 旧文件（44173 行），reextract 完成后需重新合并才能用
- StarCoder supplement watcher (PID 20226) 只跑 BM25（已独立验证脚本源码确认），registry 中 "DUPLICATE RISK" WARNING 是误报
- PID 94874 (E2E eval) 已被 Director 下令 kill 并确认清理。E2E eval 推迟到 Qwen chain 完成后

### 2. 🖥️ 基础设施快照
- 服务器：bjb1-42106 (root)，工作目录 /root/structfuse
- Python：/root/miniconda3/bin/python（conda base 环境）
- 模型：Qwen → /root/autodl-tmp/structfuse/models/Qwen/Qwen2.5-Coder-3B；StarCoder → /root/autodl-tmp/models/bigcode/starcoder2-3b/bigcode/starcoder2-3b
- 数据：M2 训练 /root/autodl-tmp/structfuse/full_m2_training_data/；M1 提取 /root/autodl-tmp/structfuse/full_m1_data/
- Checkpoints：/root/autodl-tmp/structfuse/checkpoints/m2_full_qwen/ 和 m2_full_starcoder/
- W&B：offline 模式，日志在 /root/structfuse-context/wandb/ 和 /root/autodl-tmp/structfuse/wandb_logs/
- 活跃进程：
  - PID 337267 (tmux, Qwen 主链 cuda:0)，子进程 PID 18427 (dataflow_s43, step ~1100/2810)
  - PID 519791 (tmux, StarCoder 主链 cuda:1)，子进程 PID 38016 (embed_s42, step ~600/4242)
  - PID 61328 (SWE-bench retrieval eval, cuda:0 共享, random_s42 100 instances, 已跑 ~2h)
  - PID 966920 (watch_and_chain_qwen_s42.sh, 等 Qwen 主链结束后跑 s42 supplement on cuda:0)
  - PID 20226 (watch_and_chain_starcoder_s42.sh, 等 StarCoder 主链结束后跑 BM25 only on cuda:1)
  - m1_reextract_v2: 4 CPU workers (PID 209821等)，处理 MONAI + moto 剩余

### 3. 📊 当前状态
本轮完成了：启动核实 → GPU 合规检查 → StarCoder supplement 脚本独立验证 → GPU 0 三进程资源竞争发现并报告 → Director 批准 kill E2E → dataflow_s43 eval@1000 审查 → neg_difficulty 机制分析评估 → plan_005 叙事备案评估。

Registry RUNNING:
- **m2_full_qwen_continued**: dataflow_s43 (5/7), step ~1100/2810, **eval@1000 R@1=0.5174（暴跌，early stopping 1/2 触发）**, best=0.5495 (step 500)。remaining: dataflow_s44 → bm25_s42。ETA May 17 14:00-18:00 CST（可能因 GPU 共享推迟）
- **m2_full_starcoder_resumed**: embed_s42 (4/9), step ~600/4242, **eval@500 R@1=0.4372**（vs random_s42 0.435, +0.22pp 噪声级）。ETA May 19-20 CST
- **m1_reextract_v2**: ~98.8% done, dry-run 合并显示 89.9% structural coverage。ETA May 16 10:00-12:00 CST
- **plan_003_swebench_eval**: RUNNING, PID 61328 on cuda:0, random_s42 100 instances 检索评估

PREPARING: plan_005_stratified（等 M2 checkpoints，脚本已 dry-run 验证）

### 4. 📋 待办（条件触发式）
- dataflow_s43 eval@1500 → 如 val_loss > 0.4617 则 early stop 触发，确认 dataflow_s43 final best=0.5495。记录到汇总表
- dataflow_s43 完成 → dataflow_s44 自动启动，核实正常
- m1_reextract_v2 完成 → 核实最终计数 + moto 降级质量 → 提醒 Agent 执行正式合并（非 dry-run）
- plan_003_swebench_eval (PID 61328) 完成 random_s42 → 审查 retrieval R@1/5/10 结果。这是论文 SWE-bench 部分的核心数据
- Qwen chain 全部完成 (7/7) → 立即审查全部 R@1 汇总 + 提醒启动 plan_005 stratified（Qwen-only 先行，不必等 StarCoder）
- Qwen supplement (PID 966920) 触发 → 核实 embed_s42 + dataflow_s42 + bm25_s43/s44 正常启动在 cuda:0
- **Qwen 步进率监控**：kill E2E 后应恢复到 ~200 steps/h（之前三进程约 140 steps/h）。如持续 <180 → 报 warning

### 5. 🎯 战略上下文
- **论文最大风险已实质化**：aggregate treatment effect <1pp（seed noise 主导）。三组数据确认：Qwen s43 embed +0.52pp / s44 -0.67pp, StarCoder s42 +0.22pp。dataflow 对 Qwen 实际有害 (-0.59pp)
- **两轨叙事已提交 Director**：A轨 = plan_005 stratified 发现子群异质性；B轨 = "explain when/why mining doesn't differentiate" (neg_difficulty mechanism + representation geometry)。所有已规划实验同时服务两轨，无需新实验
- **neg_difficulty mechanism**: r=-0.60, p=0.069, n=10 — suggestive not significant。n=18 后预期 p<0.01（如果 pattern 持）。论文位置取决于最终 p 值：p<0.05 → Analysis subsection；p>0.05 → Discussion explanatory note
- **plan_005 关键节点**：Qwen chain 完成后（~May 17）可立即跑 Qwen-only stratified，不必等 StarCoder。如果 Qwen stratified 确认 scenario B → 提前启动 framing pivot
- **易错点**：(1) 不要把 pilot 数据 (+2.0pp) 和 full scale (~0pp) 直接对比下结论——regime 不同 (3ep vs 2ep)、数据版本不同 (v1 vs v2)。(2) registry 中 m2_full_qwen 父实验的 random_s44 "status=RUNNING" 是过期快照。(3) SWE-bench 纯检索评估（plan_003）才是论文需要的 SWE-bench 实验，E2E resolve rate 是锦上添花不是核心
