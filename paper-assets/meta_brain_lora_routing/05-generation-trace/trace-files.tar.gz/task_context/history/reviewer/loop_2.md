---
loop: 2
reason: max_wall_time
updated: '2026-05-16T11:53:57+00:00'
---

### 1. 🔴 硬约束 / 红线
- 服务器 westd-34142 有 4× RTX PRO 6000 96GB，`execution.gpu_ids` 未明确限制但项目独占 4 张卡（cuda:0-3）
- pi0_libero checkpoint 路径：`/root/autodl-tmp/checkpoints/pi0_libero/`（7.0 GB 完整模型，非 delta）
- 旧 LoRA checkpoints（`checkpoints/lora_*_r16/`, `lora_universal_r48/`）全部在 pi0_base 上训练，**已被 D010 invalidated**，不可用于任何结论
- Registry 中 plan_002 和 plan_013 标记 DONE/success 但实质无效——引用这些数据写论文 = critical 错误
- norm_stats.json 来源：`/root/.cache/openpi/openpi-assets/checkpoints/pi0_libero.partial/assets/physical-intelligence/libero/norm_stats.json`（delta-transformed action stats）

### 2. 🖥️ 基础设施快照
- 服务器：`westd-34142(root)`，工作目录 `/root/meta_brain_lora_routing`
- Python：`/root/miniconda3/bin/python`（conda base）
- pi0_base：`/root/autodl-tmp/checkpoints/pi0_base/model.safetensors`（13 GB, F32, openpi 格式）
- pi0_libero：`/root/autodl-tmp/checkpoints/pi0_libero/model.safetensors`（7.0 GB, BF16, LeRobot 格式 — 有 `model.` key prefix）
- LIBERO 数据：`/root/autodl-tmp/libero_demos/libero_object_image/`（97 parquet, 454 eps, 67K frames）
- 活跃进程：**无**（4 GPU 全部 0% / 0 MiB）
- Eval 脚本就绪：`run_nominal_eval.sh`、`scripts/launch_v2_lora_training.sh`

### 3. 📊 当前状态
**D010 转换（pi0_base → pi0_libero）正在进行，Phase A/B/C 代码修复完成但 nominal eval 尚未启动。**

已完成审查并 post 给 Director：
1. D010 framing 影响分析（story 更强，但需新 baseline）
2. worker_setup_download_accelerate — pi0_libero 下载完成
3. worker_code_lora_retrain_prep — CLI 参数化 + launch script
4. worker_research_pi0_libero_risks — key prefix / normalization / router 三大风险
5. worker_code_norm_fix_phase_a — state/action normalization 修复
6. worker_code_d010_phase_c_router_compat — PAR Router NEED_RETRAIN（layer 6 diff=0.2856）
7. worker_code_d010_fix_train_lora_loader — key prefix fix 完成

Registry RUNNING/PREPARING：eval_par_v1, eval_univ_r16, eval_univ_r48, eval_no_routing — 全部 `conclusion: killed`，是 D010 前的残留状态，不会产生新数据。

### 4. 📋 待办
- **nominal eval 结果出现** → 验证成功率是否 >85%；如果很低，检查是 normalization mismatch 还是 delta/raw stats 混用
- **LoRA v2 训练启动** → 核对 4 路用的是 `--checkpoint /root/autodl-tmp/checkpoints/pi0_libero` + 检查 GPU 分配 cuda:0-3
- **Router v2 训练启动** → 确认用 pi0_libero 收集激活（不是 pi0_base 旧激活），验证新 router F1
- **任何 Worker 引用 plan_002/plan_013 旧数据** → 立即 critical 打回
- **Paper 章节审查请求** → 检查 Story Spine 中 "pi0: 53.6% on LIBERO-Plus" 是否已更新为 pi0_libero 实测值

### 5. 🎯 战略上下文
- 决策链：D001(MVP定义) → D002(增强) → D003(架构修正) → D004(Phase 0 GO) → D005(Research) → D006(first-token) → D007(Dream reject) → D008(数据策略) → D009(compound) → **D010(换 base checkpoint)**
- D010 是 existential reset：所有 Phase 1 实验数据归零，只有 Phase 0 的方法论结论（扰动可分类）保留，但具体 router weights 失效
- **最容易判断错的事**：assembly 中 `_build_norm_stats` 优先用 checkpoint buffers（raw action stats），但 data_loader.py 训练用 norm_stats.json（delta action stats）。这两套 stats 数值差异巨大（action dim2: -0.09 vs -0.81）。如果 nominal eval 成功率很低，第一个排查方向是这个 stats 不匹配。
- **另一个坑**：`from_checkpoints` 用 `strict=False` 加载模型——如果 key 有问题不会崩溃但会静默用随机权重。看日志中 "Missing keys" / "Unexpected keys" 数量是否 >0。
- CoRL DDL：Abstract 2026-05-26（10 天），Paper 2026-05-29（13 天）。D010 转换预计 ~8-10h wall clock（含 3h LoRA 训练 + 2h router 重训 + 2h eval），时间充裕但 GPU 一直空闲是浪费。
