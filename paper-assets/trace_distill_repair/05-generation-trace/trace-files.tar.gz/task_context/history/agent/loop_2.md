---
loop: 2
reason: max_wall_time
updated: '2026-05-15T01:43:33+00:00'
---

### 1. 🔴 硬约束 / 红线
- 服务器注册名是 `rtx6000-diagprobe`（不是 `westd-18314`，不是 `gpu-6000pro-1`）。之前因名称不匹配导致 5+ 次 Worker 失败
- GPU 白名单：cuda:0, cuda:1。项目配置已修正为 `rtx6000-diagprobe`
- **Scoring 流程严禁多 Worker 并行操作**——之前 5 次 line scoring 全部失败的根因是多 Worker 互踩（kill/patch/restart 同时进行）
- `submit_training_job` 的 command 如果用 bash builtin（source/conda activate），必须包在 `bash -c "..."`  里

### 2. 🖥️ 基础设施快照
- 服务器：`rtx6000-diagprobe`，host=connect.westd.seetacloud.com:18314，account=root
- GPU：2× NVIDIA RTX PRO 6000 Blackwell (96GB each)，driver 595.58.03，CUDA 13.2
- Python：torch 2.10.0+cu128，transformers 4.57.6，accelerate 1.13.0，peft 0.19.0，trl 1.1.0，wandb 0.26.0
- 工作目录：`/root/trace_distill_repair`
- 数据盘：`/root/autodl-tmp/`（175GB/250GB 可用），已有 Qwen3-8B + Qwen3-30B-A3B (73GB)
- API endpoint：`http://47.94.22.126/v1/chat/completions`（DeepSeek-V4-Flash）
- 活跃 Worker：`worker_ssh_cron_line_scoring_done_20260515T014221`（处理 line scoring 完成回调 + 启动 structural scoring）
- Cron：`mvp_line_scoring_clean`（PID 74506 已退出，cron 待 Worker 删除）

### 3. 📊 当前状态
Line scoring PID 74506 已退出（cron 检测到），35/38 时最后一次确认。Worker `worker_ssh_cron_line_scoring_done_20260515T014221` 正在执行：
1. 诊断 line scoring 最终结果（成功/失败）
2. 更新 registry `mvp_line_scoring_clean` → DONE
3. 删除 cron
4. 如果成功，立即 `submit_training_job` 启动 `mvp_structural_scoring_clean`（structural scoring 重跑，清除旧 bug 的 16 error + confidence=0.5 脏数据）

Registry 状态：
- `mvp_line_scoring_clean`: RUNNING（等 Worker 更新）
- `mvp_trace_collect`: DONE(success) — 38/40 成功
- `mvp_teacher_scoring`: DONE(failed) — stale RUNNING 被清理
- 其他 4 个旧实验: DONE(failed/killed)

### 4. 📋 待办
- Worker `worker_ssh_cron_line_scoring_done_20260515T014221` 回调 → 读结果，向 Director 汇报 line scoring 最终指标 + structural scoring 启动状态
- `mvp_structural_scoring_clean` cron 回调 → 收集结果，与旧版对比（旧：491 segs, 25 keep, 450 drop, 16 error），更新 registry，汇报 Director
- 两项 scoring 都完成 → Phase 3 repair 对比（`run_phase3_repair.py` 已就绪，dry-run 通过）可提交审批
- Director 待决策：research 阶段 student model 选型（ROADMAP 说 0.6B，服务器有 Qwen3-8B/30B-A3B）

### 5. 🎯 战略上下文
- **目标会议**：EMNLP 2026 ARR May，DDL 2026-05-25（距今 10 天）
- **核心论点**：结构感知分段（structural segments）优于行级过滤（line-level），修正 EMNLP 2025 "Do Code Semantics Help?" 的负面结论
- **MVP Pass 标准**：①✅ ≥80% 端到端成功率（实际 95%）②⏳ Teacher precision ≥0.6 ③⏳ >2K token 子集 structural win rate >50% (p<0.15)
- **Kill 标准**：structural win rate ≤50% in >2K subset → 终止项目
- 关键决策链：D001 MVP 设计 → D005 采样策略 head-100+tail-100 → D006 终止全量 62K → D007 JSON 解析 bug 修复
- **易踩坑**：Worker 对长时间 scoring 任务会因 session 限制退出（已发生 3 次），必须用 cron 监控而非 Worker 内 ScheduleWakeup 轮询。Worker 只负责启动 + submit_training_job，由 cron 跟踪进程存活
