---
loop: 5
reason: max_wall_time
updated: '2026-05-17T21:17:04+00:00'
---

### 1. 🔴 硬约束 / 红线
- GPU 白名单：cuda:0 和 cuda:1 only（rtx6000-diagprobe，2× RTX PRO 6000 Blackwell 98GB）
- exp_005 已被 D018 kill（PID 116947 已死），不要重启
- D015：论文主参数 k=10（exp_006），k=20（exp_005）仅为 sensitivity data
- D004：Collapse 从 Gen 1 baseline 计算（Gen 0→1 上升是 pretrained decompression，不是 collapse）
- Root 分区仅 5.2G free（83%），checkpoint 写 /root/autodl-tmp/，不要往 /root/ 写大文件

### 2. 🖥️ 基础设施快照
- 服务器：rtx6000-diagprobe (root)，代码根目录 /root/spectral_collapse_ews
- Python：/root/miniconda3/bin/python（conda base）
- 模型：EleutherAI/pythia-410m-deduped（HF cache，HF_HUB_OFFLINE=1）
- 数据：/root/spectral_collapse_ews/data/（50K real pool + eval_5k.jsonl）
- Checkpoint：/root/autodl-tmp/spectral_collapse_ews/checkpoints_phase1/
- 活跃进程：
  - exp_006 (PID 134918, tmux=exp_006, cuda:0) — 主实验 adaptive k=10
  - exp_004 (PID 135411, tmux=exp_004, cuda:1) — fixed_mix baseline
- 无 wandb 配置，无 cron

### 3. 📊 当前状态
刚完成：
- Introduction 重写审查 → PASS（幽灵引用清零，质量好）
- Related Work 重写审查 → PASS（7处幻觉→0处）
- exp_005 kill 验证 → GPU 1 已释放给 exp_004 独占
- GPU 资源冲突报告 + 引用审查报告 + Introduction/Abstract/Conclusion/Related Work 综合审查均已 post to Director

Registry：
- exp_006 RUNNING（adaptive k=10，主实验）Gen 0-2 完成，GPU 0 独占，~45min/gen
- exp_004 RUNNING（fixed_mix baseline）Gen 0-1 完成，GPU 1 独占（刚释放），预计加速至 ~1-2h/gen
- exp_005 DONE/killed，Gen 0-4 数据已保存
- exp_001 DONE（Phase 0，Gen 0-10 完整）
- linear_increasing 脚本已准备（/root/spectral_collapse_ews/scripts/launch_linear_increasing.sh），未启动

### 4. 📋 待办
- exp_006 到 Gen 3+ → 检查 controller 是否触发（k=10 下 log_det delta 是否超过 τ=0.002）。这是论文核心数据点
- exp_004 完成或 exp_006 完成 → 释放的 GPU 启动 linear_increasing 实验
- method.tex / experiments.tex 参数修复 worker 完成 → 验证 k=1.0→10, τ=0.005→0.002, T-t-1→T-t 是否全部修正（已报告 2 次 CRITICAL，至今未修）
- 新 paper section worker 完成 → 审查引用是否全部来自 references.bib 验证条目
- 论文编译 / 远程同步 → 验证本地 paper/sections/*.tex 已同步到远程 paper/*.tex（目前所有新版都只在本地，远程全是旧版带幽灵引用）

### 5. 🎯 战略上下文
- 项目：EMNLP 2026 ARR Short Paper，DDL May 25（~7天）
- 核心 story：spectral collapse 三阶段表征 + SLV 作为 EWS + 自适应 controller（PoC）+ signal attenuation paradox
- 决策链关键节点：D004（decompression baseline）→ D012（k calibration）→ D013（controller = PoC framing）→ D015（k=10 为主参数）→ D018（kill exp_005 释放 GPU）
- **最易判断错的事**：
  1. "6.7× onset signal" — 这个数字在 method.tex 和 conclusion 中出现，但我独立计算 410M 数据只有 ~1.9×。结论/方法中若仍有此数字必须修正
  2. 论文文件双源问题 — 本地 paper/sections/*.tex 是新版（无幽灵引用），远程 paper/*.tex 是旧版（满是幽灵引用）。审查时必须先确认读的是哪个版本
  3. exp_005 controller 从未触发（Gen 0-4 ratio=0.5）— 这不是 bug，是 signal attenuation paradox 的实证。50% mixing 下 log_det 持续上升，spectral collapse signal 被完全掩盖
  4. references.bib 仍缺 rankme2023、gao2020pile、data_mixing_laws2024、garg2025 四个条目，introduction 和 related work 新版引用了它们但 bib 中不存在
