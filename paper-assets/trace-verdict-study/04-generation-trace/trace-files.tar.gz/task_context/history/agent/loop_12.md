---
loop: 12
reason: idle_timeout
updated: '2026-05-16T15:15:27+00:00'
---

### 1. 🔴 硬约束 / 红线
- 本项目只能用 westd-11235 的 cuda:0 和 cuda:1（`get_project_resource_usage` 白名单）
- westd-11235 用 conda 环境（`source /root/miniconda3/etc/profile.d/conda.sh && conda activate base`），**不存在 .venv**
- DeepSeek 系列 eval 时 max_length 必须匹配训练值 2048，用 16384 会 OOD 崩溃（28.5%）——Qwen 不受影响
- 模型/数据/checkpoint 必须放 `/root/autodl-tmp/`，根分区只有 ~30GB
- HF_HOME 必须设 `/root/autodl-tmp/.hf_cache`
- ARR May 25 提交，距今 9 天

### 2. 🖥️ 基础设施快照
- **服务器**: westd-11235，工作目录 `/root/trace-verdict-study`
- **Python**: `/root/miniconda3/bin/python`（conda base env）
- **模型路径**: `/root/autodl-tmp/models/Qwen2.5-Coder-7B-Instruct`、`Qwen2.5-Coder-1.5B-Instruct`、`DeepSeek-Coder-6.7B-Instruct`
- **Checkpoint**: `/root/autodl-tmp/trace-verdict-study-checkpoints/{exp_id}/final/`
- **W&B project**: `trace-verdict-study`
- **代码 commit**: `e404237ccc765768e267d4d6fd3c89549dcf41a4`
- **活跃进程**:
  - `loop_only_seed123`: PID 261213, tmux=loop_only_seed123, cuda:1, cron 监控中
  - `qwen15b_full_trace_seed42`: cuda:0, RUNNING（刚提交，cron 已注册）

### 3. 📊 当前状态
Session #12 刚完成 session-start 初始化。前一个 loop 已处理 `qwen15b_vota_seed42` 完成回调（acc=99.58%，success）并提交了 `qwen15b_full_trace_seed42`。

**RUNNING (2)**:
- `qwen15b_full_trace_seed42`（cuda:0）— Qwen-1.5B full_trace baseline
- `loop_only_seed123`（cuda:1）— loop_only seed robustness

**Workers (2, 刚派)**:
- `worker_paper_integrate-qwen15b-data_20260516T111258` — 整合 1.5B 数据到论文表格
- `worker_infra_codellama-model-check_20260516T111311` — 验证 CodeLlama 模型是否已下载

**已向 Director 汇报**：1.5B exception_only=99.83%（与 7B 完全一致），建议升级 claim 为 "scale-invariant signal"；建议清理重复的 `qwen1.5b_*` QUEUED 实验。

### 4. 📋 待办（条件触发式）
- `qwen15b_full_trace_seed42` cron 回调 → spawn worker 读 eval 结果 → 更新 registry → cuda:0 空出后提交 CodeLlama-7B exception_only（跨家族优先）
- `loop_only_seed123` cron 回调 → 同上 → cuda:1 空出后提交 CodeLlama-7B vota 或 no_trace
- Worker `codellama-model-check` 回调 → 如模型未下载，等下载完成后再提交 CodeLlama 实验；如已有则标记 ready
- Worker `paper-integrate` 回调 → 确认数据已入表，register_artifact
- Director 回复 → 如批准清理 `qwen1.5b_*` 重复项则执行；如批准 "scale-invariant" claim 升级则更新 paper_framing.md
- 两卡都空出 → 按优先级：CodeLlama-7B（跨家族）> CodeLlama-13B > nomarker ablation > 剩余 seed

### 5. 🎯 战略上下文
- **核心发现**: Exception events 是 verdict prediction 最有效的 trace 组件。Qwen-7B/1.5B exception_only 均 99.83%（scale-invariant），DeepSeek 2/3 seeds 99.33%。DebugBench 跨任务 100%。
- **Paper framing v3.0**: 3 core claims FINALIZED（exception dominance / cross-model / cross-task）
- **决策链**: D044→D047 完成 regex+DebugBench 验证；当前是收官阶段（seed robustness + 跨家族 CodeLlama + paper draft）
- **QUEUED 14 个实验中 `qwen1.5b_*` 4 个疑似与已完成的 `qwen15b_*` 重复**——等 Director 确认后清理，不要盲目提交
- **CodeLlama 模型可能未下载**——Worker 正在验证，提交前必须等确认
- **Paper 13→8 页压缩**（D042/D043: Discussion 移 appendix）尚未执行，是 paper 关键路径
- **Cron 有误判历史**——收到 cron failed 回调时派 Worker SSH 实际验证，不要直接标 failed
