---
loop: 7
reason: max_messages
updated: '2026-05-16T14:23:25+00:00'
---

### 1. 🔴 硬约束 / 红线
- 本项目只能用 cuda:0 / cuda:1（westd-11235）
- 论文 .tex 真源路径是服务器 `/root/trace-verdict-study/docs/paper/`，所有 paper 编辑必须 ssh_execute 在该路径执行（C001，之前 Agent 在错误路径操作导致 4 轮修复失败）
- CodeLlama 用 13B-Instruct（用户批准），不是 7B。registry 里 `codellama_*`（无13b）是旧 orphan，已 killed
- `qwen1.5b_*`（带点号）是旧命名 orphan，实际用 `qwen15b_*`（无点号）

### 2. 🖥️ 基础设施快照
- 服务器：westd-11235 (connect.westd.seetacloud.com)，root
- 工作目录：`/root/trace-verdict-study/`
- 论文目录：`/root/trace-verdict-study/docs/paper/`
- 模型路径：CodeLlama-13B 在 `/root/autodl-tmp/models/CodeLlama-13b-Instruct-hf/` 或 `/root/trace-verdict-study/models/`
- 训练脚本：`/root/trace-verdict-study/train_sft.py`
- Eval 脚本：`/root/trace-verdict-study/evaluate.py`
- 活跃进程：codellama13b_exception_only_seed42 (PID 271776, cuda:0)；codellama13b_no_trace_seed42 完成 (76.47%)

### 3. 📊 当前状态
- **codellama13b_exception_only_seed42**: RUNNING cuda:0，~30min to completion。THE critical experiment — 如果 ≥99% 则 signal-limited claim 跨三家族确认
- **codellama13b_no_trace_seed42**: DONE, 76.47%（Reviewer 已验证 PASS）
- **loop_only_seed456**: DONE, 86.64%。loop_only 3-seed = 86.05% ± 0.53pp
- cuda:1 空闲，等 codellama13b_exception_only 完成后 → codellama13b_vota_seed42

### 4. 📋 待办
- codellama13b_exception_only 完成 → 如 ≥99%: D048 升级 signal-limited claim 措辞为 "demonstrate"；如 <99%: 保持 Discussion finding
- codellama13b_exception_only 完成 → cuda:0 接 codellama13b_vota_seed42
- codellama13b 三实验全部完成 → 启动 exception_only_nomarker_seed42/123/456（format marker removal，回应 R1-N1）
- 所有新实验完成 → Paper Agent patch：Table 1 加 Qwen-1.5B + CodeLlama-13B 行、Discussion 加 caught exception 分析 + scale gradient 叙事、Limitations 更新（"only two models at ~7B" 已过时）
- 论文集成完 → submit_paper_to_review Round 6

### 5. 🎯 战略上下文
- 核心发现链：D048(scale-invariance Discussion finding) → D049(irreducible error universal, mechanistic) → D050(scale gradient monotonic) → D051(DeepSeek gap = MBPP/113 caught exception) → D052(id=901/905 causal proof: signal-induced not sample-difficulty)
- **最关键判断**：codellama13b_exception_only 结果决定 claim 升级。≥99% = 跨三家族(Qwen/DeepSeek/LLaMA) + 跨三 scale(1.5B/7B/13B) 验证，可从 "suggesting" 升 "demonstrating"
- **易踩坑**：论文编辑路径必须是 `/root/trace-verdict-study/docs/paper/`（不是 `/root/trace-verdict-study/paper/`，后者不存在）
- **id=901/905 因果方向**：no_trace 下被正确预测 → irreducible error 是 representation-induced（GeneratorExit 被标为 [ERROR]），不是样本固有难度。论文应强调这个因果方向
- EMNLP 2026 ARR May 25 DDL，还剩 9 天。sprint plan 在 ROADMAP v9
