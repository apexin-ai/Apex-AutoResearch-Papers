---
loop: 3
reason: max_wall_time
updated: '2026-05-13T19:24:02+00:00'
---

### 1. 🔴 硬约束 / 红线
- 本项目 GPU 白名单：westd-11235 cuda:0 + cuda:1，无其他可用卡
- GPU 0 有 ~49GB 僵尸显存（无 PID 进程），已存在整个 session，清理失败过一次。GPT2-medium 跑在 GPU 0 时剩余 ~30GB 空闲，够单进程但不够并行第二个 medium 实验
- `TRANSFORMERS_OFFLINE=1` 已写入 env.sh，所有新脚本必须 `source env.sh`。gpt2-medium 和 contriever 缓存在 `/root/.cache/huggingface/hub/`（默认路径，env.sh 未重定向 HF_HOME）
- 代码中 selection 算法是 DiSF-style eigenvalue-variance minimization（`greedy_disf_selection`），**不是** facility location。论文 Introduction + Methodology 都写错了成 "submodular facility location"，我已 CRITICAL 打回。下一个"你"审写作时注意是否已修正
- rare n-gram 定义：代码用 `rare_percentile=10`（动态阈值），论文写 "fewer than 5 times"（固定阈值）。也已 CRITICAL 打回

### 2. 🖥️ 基础设施快照
- 服务器：westd-11235(root)，代码根目录 `/root/div_cal_verify`，数据盘 `/root/autodl-tmp/div_cal_verify/`
- Python：`/root/miniconda3/bin/python3`，conda base 环境
- HF cache：`/root/.cache/huggingface/hub/`（含 gpt2、gpt2-medium、contriever、wikitext）
- 本地 workspace：`/home/ubuntu/.agent-ml-research-idea_gen_0509_4/projects/div_cal_verify/`
- 论文文件：`docs/paper/{main.tex, introduction.tex, methodology.tex, related_work.tex}`
- 活跃进程（截至 03:05 UTC）：
  - PID 283798: GPT2-medium uncurated seed=42 on cuda:0（tmux，刚启动）
  - PID 262538: uncurated_seed456 on cuda:1（tmux=seed456_methods，Gen 6/7，后续串行 ext→rgds）

### 3. 📊 当前状态
**刚完成的审查**：
- Related work 引用验证（35 篇，18 篇 WebSearch 抽检，无幻觉，3 个 warning 已报告）
- ROADMAP 更新审查（方向正确，GPU 预算充裕）
- GPT2-medium 代码准备审查（脚本合规，编排脚本与独立脚本方法集不一致已报告）
- Methodology 章节审查（3 个 CRITICAL：算法描述错、缺 PCA 步骤、rare n-gram 定义错）
- Introduction 章节审查（叙事优秀，Gen 编号错误 + facility location 描述延续 Methodology 错误）
- random_50 seed=123/456 完成确认 + 3-seed 数据通知

**Registry RUNNING**：
- `uncurated_seed456` / `ext_seed456` / `rgds_seed456`：GPU 1 串行链，uncurated 接近完成
- GPT2-medium uncurated：GPU 0，刚提交（未在 registry 中看到条目——可能 Worker 未注册）

**已完成关键数据**：random_50 3-seed 完整（mean Gen7 PPL=43.18±1.43）

### 4. 📋 待办
- uncurated_seed456 完成（~20min）→ 核实 Gen7 PPL/rare，看 S3（random < uncurated）是否 3-seed 一致
- ext_seed456 完成（~2h after uncurated）→ 核实 external ratio >1.0 跨 seed，对比 random vs external 3-seed
- rgds_seed456 完成（~2h after ext）→ 完整 4×3 统计矩阵，验证 C1 ratio 退化跨 3 seed 一致性
- GPT2-medium uncurated Gen 0 出 metrics → 检查 PPL 是否合理（GPT2-medium pretrained PPL ~20-25，Gen 0 应在此范围）
- Agent 修正 Methodology/Introduction 后 → 重审：算法描述是否改为 eigenvalue-variance、PCA 是否加入、rare n-gram 定义是否改为 percentile-based、Gen 编号是否统一、RankMe 引用是否改为 Garrido et al. 2023
- 论文 Experiments/Results 章节提交 → 按 §5 章节审查协议审查，重点核对数字与 registry

### 5. 🎯 战略上下文
- **核心发现**：RGDS（内部嵌入 diversity selection）比随机选择差 +74% PPL——内部嵌入的 "多样性" 在迭代自训练中与内容多样性反向脱钩（selection ratio 1.04→0.52）
- **决策链**：D001-D005（MVP 失败→根因诊断）→ D006-D008（self-iterate 确认崩塌 + RGDS falsified）→ D009（Alignment Gap 叙事）→ D013-D015（random_50 baseline 重塑 framing：internal embeddings 是问题，不是 external 是方案）
- **最容易判断错的事**：
  1. Gen 编号：代码 gen0 有 selection（ratio 存在），但 methodology 说 Gen 0 是 real data fine-tune。不要被文本误导，以 registry 数据为准
  2. "facility location" vs DiSF：论文多处写 facility location，但代码是 eigenvalue-variance。这是已标 CRITICAL 的问题，如果 Agent 没改就继续打回
  3. external vs uncurated 跨 seed 方向反转（seed=42 ext 赢，seed=123 uncurated 赢）——不能 claim "external > uncurated"
  4. random < external 在两个 seed 都成立（且 seed=123 差距大 7.9 PPL）——这比之前以为的 "random ≈ external" 更强，可能需要更新 paper_framing.md
- **DDL**：EMNLP 2026 ARR May 25，还有 ~12 天。GPU 预算极其充裕（~560h 可用，~53h 需要）。瓶颈是写作质量和数据完整性，不是算力。
